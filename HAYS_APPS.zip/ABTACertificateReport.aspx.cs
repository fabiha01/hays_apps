﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using System.Net;
using Telerik.Web.UI;

namespace Apps.SPAM
{
    public partial class ABTACertificateReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblerror.Visible = false;
            using (HaysTravelLtd_MSCRMEntities CRM = new HaysTravelLtd_MSCRMEntities())
                {
                    if (!Page.IsPostBack)
                    {
                        var tn = CRM.joy_cvmtradingname.Where(x => x.statecode == 0).Select(x => new { x.joy_name, x.joy_cvmtradingnameId });
                        ddlTradingName.DataSource = tn.ToList();
                        ddlTradingName.DataValueField = "joy_cvmtradingnameId";
                        ddlTradingName.DataTextField = "joy_name";
                        ddlTradingName.DataBind();
                        ddlTradingName.Items.Insert(0, "Please Select a Trading Name");
                    }
            }
        }
        
        protected void btnRun_Click(object sender, EventArgs e)
        {

            LoadedReportonPostBack();
        }

        private void LoadedReportonPostBack()
        {

        }

        private void LoadedReport(string spTradingName)
        {
            sslDDLABTACertificate.SelectParameters[0].DefaultValue = spTradingName;
        }

        protected void rgABTACertificate_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
        {
            rgABTACertificate.DataSource = sslDDLABTACertificate;
        }

        protected void ddlTradingName_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblerror.Visible = false;

            try
            {
                if (ddlTradingName.SelectedValue == "Please Select a Trading Name")
                {
                    lblerror.Text = "Please Select a Trading Name";
                    lblerror.Visible = true;
                }
                else
                {
                    LoadedReport(ddlTradingName.SelectedValue.ToString());
                }
            }
            catch (Exception ex)
            {
                lblerror.Text = ex.Message;
                lblerror.Visible = true;
            }
        }
    }
}