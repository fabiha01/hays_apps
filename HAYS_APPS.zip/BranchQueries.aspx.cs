﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data;
using Microsoft.Reporting.WebForms;
using System.Net;
using static ExcExtensions;
using static Apps.AppsHelper;
using Telerik.Web.UI;

namespace Apps.SPAM
{
    public partial class BranchQueries : System.Web.UI.Page
    {
        string sUsername;
        int BranchView;
        int n;
        int ReportView;
        DateTime testdate;
        string comment;
        SqlGuid sqlguid;
        DataTable datatable = new DataTable();


        protected void Page_Load(object sender, EventArgs e)
        {
            string branchcode;
            if (Session["Username"] != null)
            {
                sUsername = Session["Username"].ToString();

                if (int.TryParse(sUsername, out n) == true)
                {
                    //add a 0 to username with only 00
                    if (sUsername.Length == 3)
                    {
                        sUsername = "0" + sUsername;

                    }
                }
            }

            if (Request.QueryString["BSQ"] == "1")
            {
              
                ReportView = 0;
                lblTitle.Text = "SPAM: Branch and Supplier Queries";
                // create the grid dynamically because using the session vaiable to detemand which grid is created 
                if (sUsername.Length < 5)
                {
                    // branch view
                    mvwBranchQueriesViews.ActiveViewIndex = 0;
                    BranchView = 0;

                    // stop post back which affect the sort 
                    if(!Page.IsPostBack)
                    {
                        LoadBranchQueries(sUsername, BranchView, 1);

                    }

                    // hide the control
                    lblInfo.Text = "";
                    lblInfo.Visible = false;
                    lblBranchCode.Visible = false;
                    //lblTradingName.Visible = false;
                    //selTradingName.Visible = false;
                    lblQueriesType.Visible = false;
                    selBranchCode.Visible = false;
                    txtDepartureDateFrom.Visible = false;
                    txtDepartureDateTo.Visible = false;
                    ddlQueriesType.Visible = false;
                    bntRun.Visible = false;
                    spFromDateIcon.Visible = false;
                    spToDateIcon.Visible = false;
                    lblCreatedFrom.Visible = false;
                    txtBranchID.Enabled = false;
                }
                else
                {
                    BranchView = 1;

                    txtDepartureDateFrom.Visible = false;
                    txtDepartureDateTo.Visible = false;
                    spFromDateIcon.Visible = false;
                    spToDateIcon.Visible = false;
                    lblCreatedFrom.Visible = false;
                    // head office view
                    mvwBranchQueriesViews.ActiveViewIndex = 1;

                    if (!Page.IsPostBack)
                    {
                        using (HaysTravelLtd_MSCRMEntities CRM = new HaysTravelLtd_MSCRMEntities())
                        {
                            if (!Page.IsPostBack)
                            {
                                var tn = CRM.joy_cvmtradingname.Where(x => x.statecode == 0).Select(x => new { x.joy_name, x.joy_cvmtradingnameId });
                                //selTradingName.DataSource = tn.ToList();
                                //selTradingName.DataValueField = "joy_cvmtradingnameId";
                                //selTradingName.DataTextField = "joy_name";
                                //selTradingName.DataBind();
                                //selTradingName.Items.Insert(0, "Please Select a Trading Name");

                            }
                        }
                    }
                            //filter Trading Names if Necessary
                            if (Request["__EVENTTARGET"] == "selTradingName")
                            {
                                //if (selTradingName.Value != "Please Select a Trading Name")
                                //{
                                //    //Filter Trading Name
                                //    Guid leGuid = Guid.Parse(selTradingName.Value);
                                //}
                            

                                LoadBranchQueries(selBranchCode.Value, BranchView, Convert.ToInt32(ddlQueriesType.SelectedValue));

                            }
                     
                  
                    using (SpamEntities spam = new SpamEntities())
                    {
                        if (!Page.IsPostBack)
                        {
                            var br = spam.DWX_Branch.Where(x => x.BranchName != "Unknown").Select(x => new { Branchname = x.BranchID + "-" + x.BranchName, x.BranchID });
                            selBranchCode.DataSource = br.ToList();
                            selBranchCode.DataValueField = "BranchID";
                            selBranchCode.DataTextField = "BranchName";
                            selBranchCode.DataBind();
                            selBranchCode.Items.Insert(0, "Please Select a Branch");

                        }

                        if (Request["__EVENTTARGET"] == "selBranchCode")
                        {
                            if (selBranchCode.Value != "Please Select a Branch")
                            {
                                branchcode = selBranchCode.Value;

                                branchcode = spam.DWX_Branch.Where(x => x.BranchID == branchcode).Select(x => x.BranchID + "-" + x.BranchName).FirstOrDefault();
                                selBranchCode.Value = branchcode;
                                LoadBranchQueries(selBranchCode.Value, BranchView, Convert.ToInt32(ddlQueriesType.SelectedValue));
                            }
                            else
                            {
                                var br = spam.DWX_Branch.Where(x => x.BranchName != "Unknown").Select(x => new { Branchname = x.BranchID + "-" + x.BranchName, x.BranchID });
                                selBranchCode.DataSource = br.ToList();
                                selBranchCode.DataValueField = "BranchID";
                                selBranchCode.DataTextField = "BranchName";
                                selBranchCode.DataBind();
                                selBranchCode.Items.Insert(0, "Please Select a Branch");
                            }

                        }
                    }
                }
            }
           else
            {
                if (sUsername.Length > 5)
                {
                    ReportView = 1;

                    lblTitle.Text = "SPAM: Branch Queries Audit Report";
                    mvwBranchQueriesViews.ActiveViewIndex = 2;
                    //lblDepDate.Text = "Date Created From:";
                    //selTradingName.Visible = false;
                    lblBranchCode.Text = "Date Created To:";
                    selBranchCode.Visible = false;
                    lblQueriesType.Visible = false;
                    ddlQueriesType.Visible = false;
                }
                else
                {
                    Response.Redirect("~/SPAM/BranchQueries.aspx?BSQ=1");
                }
            }          
        }
        protected void bntRun_Click(object sender, EventArgs e)
        {
            lblError.Visible = false;
            try
            {
                if(ReportView == 0)
                {
                    LoadBranchQueries(selBranchCode.Value, BranchView, Convert.ToInt32(ddlQueriesType.SelectedValue));
                }
                else
                {
                    if(DateTime.TryParse(txtDepartureDateFrom.Text, out testdate) == false)
                    {
                        lblError.Text = "Invaild From Departure Date";
                        lblError.Visible = true;


                    }
                    else if(DateTime.TryParse(txtDepartureDateTo.Text, out testdate) == false)
                    {
                        lblError.Text = "Invaild To Departure Date";
                        lblError.Visible = true;
                        
                    }
                    else
                    {
                        loadreport(txtDepartureDateFrom.Text, txtDepartureDateTo.Text);
                    }
                }
                
            }
            catch(Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
           
        }
     
        private void LoadBranchQueries(string spUsername , int siBranchView, int siQueryType)
        {
            int iBranchID;

            lblInfo.Text = "";
            lblInfo.Visible = false;

            // pass sptradingname as a guid 
            //if (spTradingName != "Please Select a Trading Name" && !string.IsNullOrEmpty(spTradingName))
            //{
            //    sqlguid = new SqlGuid(spTradingName);
            //}

            if (spUsername == "Please Select a Branch")
            {
                sslDDLBranchQueries.SelectParameters[0].DefaultValue = null;
            }
            else
            {
                sslDDLBranchQueries.SelectParameters[0].DefaultValue = spUsername;
            }

            //if (spTradingName == "Please Select a Trading Name")
            //{
            //    sslDDLBranchQueries.SelectParameters[1].DefaultValue = null;
            //}
            //else
            //{
            //    sslDDLBranchQueries.SelectParameters[1].DefaultValue = spTradingName;
            //}
            if (siQueryType == 0)
            {
                sslDDLBranchQueries.SelectParameters[2].DefaultValue = null;
            }
            else
            {
                sslDDLBranchQueries.SelectParameters[2].DefaultValue = siQueryType.ToString();
            }
            
            // change the view depended on branch view selected
            if (siBranchView == 0)
            {
                //rgBranchQueries.DataSource = sslDDLBranchQueries;
                rgBranchQueries.DataBind();

                if (rgBranchQueries.Items.Count >= 1)
                {
                    rgBranchQueries.Visible = true;
                    colourcommentBox(1);

                }
                else
                {
                    rgBranchQueries.Visible = false;
                    lblInfo.Text = "No Branch Queries";
                    lblInfo.Visible = true;
                }
            }
            else
            {
                rgHeadOfficeView.DataBind();

                if (rgHeadOfficeView.Items.Count >= 1)
                {

                    rgHeadOfficeView.Visible = true;
                    colourcommentBox(2);


                }
                else
                {
                    rgHeadOfficeView.Visible = false;
                    lblInfo.Text = "No Branch Queries";
                    lblInfo.Visible = true;
                }
               

            }
           
        }
        private void colourcommentBox (int gridview)
        {
            int iObjectKey;
            string sElementRef;

            if(gridview == 1)
            {
                using (SpamEntities spam = new SpamEntities())
                {
                    foreach (GridItem row in rgBranchQueries.Items)
                    {
                        Label lblObjectKey = row.FindControl("lblObjectKey") as Label;
                        iObjectKey = Convert.ToInt32(lblObjectKey.Text);

                        var cmts = spam.SPM_Comments.Where(x => x.ObjectKey == iObjectKey && x.DeletedFlag == false);

                        if (cmts.Count() > 0)
                        {
                            LinkButton lnkComment = row.FindControl("lntComment") as LinkButton;
                            lnkComment.ForeColor = System.Drawing.Color.DarkOrange;
                        }

                        LinkButton lbtElementRef = row.FindControl("lbtElementRef") as LinkButton;
                        sElementRef = lbtElementRef.Text;

                        var Refundscmts = spam.SPM_Comments.Where(x => x.ObjectRef == sElementRef && x.DeletedFlag == false);
                        if (Refundscmts.Count() > 0)
                        {
                            LinkButton lnkComment = row.FindControl("lntComment") as LinkButton;
                            lnkComment.ForeColor = System.Drawing.Color.DarkOrange;
                        }

                    }
                }
            }
            else
            {

                using (SpamEntities spam = new SpamEntities())
                {
                    foreach (GridItem row in rgHeadOfficeView.Items)
                    {
                        Label lblObjectKey = row.FindControl("lblObjectKey") as Label;
                        iObjectKey = Convert.ToInt32(lblObjectKey.Text);

                        var cmts = spam.SPM_Comments.Where(x => x.ObjectKey == iObjectKey && x.DeletedFlag == false);
                        if (cmts.Count() > 0)
                        {
                            LinkButton lnkComment = row.FindControl("lntComment") as LinkButton;
                            lnkComment.ForeColor = System.Drawing.Color.DarkOrange;
                        }

                        //colour refunds comments
                        LinkButton lbtElementRef = row.FindControl("lbtElementRef") as LinkButton;
                        sElementRef = lbtElementRef.Text;

                        var Refundscmts = spam.SPM_Comments.Where(x => x.ObjectRef == sElementRef && x.DeletedFlag == false);
                        if (Refundscmts.Count() > 0)
                        {
                            LinkButton lnkComment = row.FindControl("lntComment") as LinkButton;
                            lnkComment.ForeColor = System.Drawing.Color.DarkOrange;
                        }
                    }
                }
            }
        }
        protected void ddlQueriesType_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadBranchQueries(selBranchCode.Value, BranchView, Convert.ToInt32(ddlQueriesType.SelectedValue));
        }

        private void loadreport(string DateDepartureFrom, string DateDepartureTo)
        {
            
        }
  
        protected void gvwBranchQueries_Sorting(object sender, GridViewSortEventArgs e)
        {

            LoadBranchQueries(sUsername, BranchView,1);
        
            colourcommentBox(1);
        
        }
        
        protected void lnkViewIsell_Click(object sender, EventArgs e)
        {
            LinkButton btnIsell = sender as LinkButton;
            string[] commandArgs = btnIsell.CommandArgument.ToString().Split(new char[] { ';' });

            string portfolio = commandArgs[0];
            string company = commandArgs[1];

            switch (company)
            {
                case "Hays Travel Ltd":
                    company = "HAY";
                    break;
                case "Hays Tour Operating Ltd":
                    company = "HTR";
                    break;
                default:
                    throw new Exception("WRONG COMPANY");
            }

            string url = string.Format("https://isell.traveltek.net/{0}/backoffice/bocostings.pl?bookingid={1}", company, portfolio);

            Response.Redirect(url);
        }

        protected void lnkViewNav_Click(object sender, EventArgs e)
        {
            LinkButton btnNav = sender as LinkButton;
            string[] commandArgs = btnNav.CommandArgument.ToString().Split(new char[] { ';' });

            string elementRef = commandArgs[0];
            string analysis1 = elementRef.Split(new char[] { '/' })[0];
            string analysis2 = elementRef.Split(new char[] { '/' })[1];
            string company = commandArgs[1];

            string url = string.Format("dynamicsnav://navappserv:7050/DynamicsNAV80/{0}/runpage?page=29&$filter='Vendor Ledger Entry'.'Analysis 1' IS '{1}' AND 'Vendor Ledger Entry'.'Analysis 2' IS '{2}'&mode=View",
                                        company, analysis1, analysis2);
            Response.Redirect(url);
        }

        protected void lntComment_Click(object sender, EventArgs e)
        {
            btnUpdate.Enabled = true;
            txtCommentHistory.Text = "";
            txtNewComment.Text = "";
            lblErrorSavedBox.Text = "";

            LinkButton bntsubmit = sender as LinkButton;

            string[] commandArge = bntsubmit.CommandArgument.ToString().Split(new char[] { ';' });

            hidCommentID.Value = commandArge[0];
            hidObjectKey.Value = commandArge[1];
            hidCommentType.Value = commandArge[2];

            if (sUsername.Length < 5)
            {
                txtBranchID.Visible = false;
                txtBranchID.Text = commandArge[3];
                divBranchID.Visible = false;
                divQueryStatus.Visible = false;
                ddlQueryStatus.Visible = false;
                ddlQueryStatus.SelectedValue = commandArge[4];
            }
            else
            {
                txtBranchID.Text = commandArge[3];
                ddlQueryStatus.SelectedValue = commandArge[4];
            }
            

            SqlConnection conn2 = new SqlConnection();
            SqlCommand cmd2 = new SqlCommand();
            conn2.ConnectionString = (string)Session["conDWADMIN2"];
            // other varaibles 
            cmd2.CommandType = CommandType.StoredProcedure;
            cmd2.Connection = conn2;
            cmd2.CommandText = "usp_APPS_SPM_Get_Branch_Queries_Comment";
            conn2.Open();

            SqlParameter pCommentID = cmd2.Parameters.Add("@CommentID", SqlDbType.Int);
            pCommentID.Direction = ParameterDirection.Input;
            pCommentID.Value = Convert.ToInt32(hidCommentID.Value);

            SqlParameter pObjectKey = cmd2.Parameters.Add("@ObjectKey", SqlDbType.Int);
            pObjectKey.Direction = ParameterDirection.Input;
            pObjectKey.Value = Convert.ToInt32(hidObjectKey.Value);

            using (SqlDataReader data = cmd2.ExecuteReader())
            {
                while (data.Read())
                {
                    // show the comment 
                    txtCommentHistory.Text = data["CommentText"].ToString() + Environment.NewLine;
                }
            }

            //this show date and time stamp order 
            txtCommentHistory.Text = txtCommentHistory.Text.Replace("--", Environment.NewLine);
            conn2.Close();
            popup.Attributes["class"] = "lbpopup";
            overlay.Attributes["class"] = "lboverlay";
        }


        protected void bntClose_Click(object sender, EventArgs e)
        {
            popup.Attributes["class"] = "lbpopuph";
            overlay.Attributes["class"] = "lboverlayh";
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            
            SavedBranchQueries(1);
            popup.Attributes["class"] = "lbpopuph";
            overlay.Attributes["class"] = "lboverlayh";

            // re-binded the grid
            if (sUsername.Length < 5)
            {

            rgBranchQueries.DataSource = sslDDLBranchQueries;
            rgBranchQueries.DataBind();
                colourcommentBox(1);
            }
            else
            {
                colourcommentBox(2);

            }
        }
        private void SavedBranchQueries(int SavedID)
        {
            btnUpdate.Enabled = false;

            SqlConnection conn2 = new SqlConnection();
            SqlCommand cmd2 = new SqlCommand();

            conn2.ConnectionString = (string)Session["conDWADMIN2"];

            // saved comments 
            if (SavedID == 1)
            {
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Connection = conn2;
                cmd2.CommandText = "usp_APPS_SPM_Insert_Branch_Queries_Comment";

                SqlParameter pCommentID = cmd2.Parameters.Add("@CommentID", SqlDbType.Int);
                pCommentID.Direction = ParameterDirection.Input;
                pCommentID.Value = Convert.ToInt32(hidCommentID.Value);

                SqlParameter pCommentType = cmd2.Parameters.Add("@CommentType", SqlDbType.Int);
                pCommentType.Direction = ParameterDirection.Input;
                pCommentType.Value = Convert.ToInt16(hidCommentType.Value);

                SqlParameter pObjectKey = cmd2.Parameters.Add("@ObjectKey", SqlDbType.Int);
                pObjectKey.Direction = ParameterDirection.Input;
                pObjectKey.Value = Convert.ToInt32(hidObjectKey.Value);

                if (txtCommentHistory.Text.Length > 0)
                {
                    if (txtNewComment.Text.Trim().Length > 0)
                    {
                        comment = DateTime.Now.ToString() + " -- " + sUsername + " - " + txtNewComment.Text.Trim() + " -- " + txtCommentHistory.Text;
                    }
                    else
                    {
                        comment = txtCommentHistory.Text;
                    }

                }
                else
                {
                    if (txtNewComment.Text.Trim().Length > 0)
                    {
                        comment = DateTime.Now.ToString() + " -- " + sUsername + " - " + txtNewComment.Text.Trim() + " -- " + txtCommentHistory.Text;
                    }

                }

                SqlParameter pComment = cmd2.Parameters.Add("@CommentText", SqlDbType.VarChar, 2000);
                pComment.Direction = ParameterDirection.Input;
                pComment.Value = comment;

                SqlParameter pUserName = cmd2.Parameters.Add("@UserName", SqlDbType.VarChar, 50);
                pUserName.Direction = ParameterDirection.Input;
                pUserName.Value = sUsername;

                SqlParameter pBranchID = cmd2.Parameters.Add("@BranchID", SqlDbType.VarChar, 4);
                pBranchID.Direction = ParameterDirection.Input;
                pBranchID.Value = txtBranchID.Text;

                SqlParameter pQueryStatus = cmd2.Parameters.Add("@QueryStatus", SqlDbType.Int);
                pQueryStatus.Direction = ParameterDirection.Input;
                pQueryStatus.Value = Convert.ToInt32(ddlQueryStatus.SelectedValue);

                conn2.Open();
                cmd2.ExecuteNonQuery();
                conn2.Close();
                txtCommentHistory.Text = comment.Replace("--", Environment.NewLine);
                txtNewComment.Text = "";
            }
            else
            {
                foreach (GridItem row in rgHeadOfficeView.Items)
                {
                      DropDownList ddlreason = row.FindControl("ddlreason") as DropDownList;
                      Label lblObjectKey = row.FindControl("lblObjectKey") as Label;
      
                    if(Convert.ToInt32(ddlreason.SelectedValue) !=0)
                    {
                        cmd2.CommandType = CommandType.StoredProcedure;
                        cmd2.Connection = conn2;
                        cmd2.CommandText = "usp_APPS_SPM_Insert_SPAM_Reason";

                        SqlParameter pCommentID = cmd2.Parameters.Add("@Reason", SqlDbType.Int);
                        pCommentID.Direction = ParameterDirection.Input;
                        pCommentID.Value = Convert.ToInt32(ddlreason.SelectedValue);

                        SqlParameter pObjectKey = cmd2.Parameters.Add("@QueryID", SqlDbType.Int);
                        pObjectKey.Direction = ParameterDirection.Input;
                        pObjectKey.Value = Convert.ToInt32(lblObjectKey.Text);

                        conn2.Open();
                        cmd2.ExecuteNonQuery();

                        cmd2.Parameters.Clear();
                        conn2.Close();
                    }
                                       
                }

                LoadBranchQueries(selBranchCode.Value, BranchView, Convert.ToInt32(ddlQueriesType.SelectedValue));
            }
        }
        
        protected void ddlReason_SelectedIndexChanged(object sender, EventArgs e)
        {
            SavedBranchQueries(2);
        }

        // report credentails 
        public class CustomReportCredentials : IReportServerCredentials
        {
            private string _UserName;
            private string _PassWord;
            private string _DomainName;

            public CustomReportCredentials(string UserName, string PassWord, string DomainName)
            {
                _UserName = UserName;
                _PassWord = PassWord;
                _DomainName = DomainName;
            }

            public System.Security.Principal.WindowsIdentity ImpersonationUser
            {
                get { return null; }
            }

            public ICredentials NetworkCredentials
            {
                get { return new NetworkCredential(_UserName, _PassWord, _DomainName); }
            }

            public bool GetFormsCredentials(out Cookie authCookie, out string user,
             out string password, out string authority)
            {
                authCookie = null;
                user = password = authority = null;
                return false;
            }
        }

        protected void lnkViewIsell_Click1(object sender, EventArgs e)
        {
            lblError.Visible = false;

            try
            {
                LinkButton lnkViewIsell = sender as LinkButton;
                string BookingRef = lnkViewIsell.CommandArgument.Split('/')[0];
                string sSystem = BookingRef.Substring(0, 3);
                string sURL;

                switch (sSystem)
                {
                    case "HAY":
                        sURL = "http://www.haystravel.co.uk/extranet/index.pl?action=bookingsearch&reference=" + BookingRef;
                        break;
                    case "HTR":
                        sURL = "https://secure.traveltek.net/HTR/extranet/index.pl?action=bookingsearch&reference=" + BookingRef;
                        break;
                    case "HBD":
                        sURL = "https://secure.traveltek.net/HBD/extranet/index.pl?action=bookingsearch&reference=" + BookingRef;
                        break;
                    case "HTF":
                        sURL = "https://secure.traveltek.net/HTF/extranet/index.pl?action=bookingsearch&reference=" + BookingRef;
                        break;
                    case "BTM":
                        sURL = "http://162.13.221.208/dhruvonweb/booking/index/" + BookingRef.Substring(4, BookingRef.Length - 4);
                        break;
                    default:
                        sURL = "NO";
                        break;
                }

                string sScript = "window.open('" + sURL + "', '_blank');";
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "sellsys", sScript, true);
            }
            catch
            {
                lblError.Text = "Can't displayed selling system";
                lblError.Visible = true;
            }
        }
        protected void gvwBranchQueries_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label lblStatus = (Label)e.Row.FindControl("lblStatus");

                //if it is manual payment hide the row for branches
                if (lblStatus.Text == "Manual Payment")
                {
                    e.Row.Visible = false;
                }
            }
        }

        protected void rgHeadOfficeView_ItemDataBound(object sender, GridItemEventArgs e)
        {
            if (e.Item.ItemType == GridItemType.Item)
            {
                // create a drop down list 
                DropDownList ddlReason = e.Item.FindControl("ddlReason") as DropDownList;

                ((DropDownList)e.Item.FindControl("ddlReason")).SelectedValue =
               DataBinder.Eval(e.Item.DataItem, "Reason").ToString();

            }
        }

        protected void rtBranchQueriesAudit_ButtonClick(object sender, RadToolBarEventArgs e)
        {
            RadToolBarButton btn = e.Item as RadToolBarButton;

            if (btn.CommandName == "ExportToExcel")
            {
                rgBranchQueriesAudit.ExportSettings.FileName = "ExportedFile";
                rgBranchQueriesAudit.MasterTableView.GetColumn("Comment2").Display = true;
                rgBranchQueriesAudit.ExportSettings.Excel.Format = (GridExcelExportFormat)Enum.Parse(typeof(GridExcelExportFormat), "Xlsx");
                rgBranchQueriesAudit.ExportSettings.IgnorePaging = true;
                rgBranchQueriesAudit.ExportSettings.ExportOnlyData = true;
                rgBranchQueriesAudit.ExportSettings.OpenInNewWindow = true;
                rgBranchQueriesAudit.MasterTableView.ExportToExcel();
            }
            else if(btn.CommandName =="ExportCSV")
            {
                //rgBranchQueriesAudit.MasterTableView.ExportToCSV();
                rgBranchQueriesAudit.ExportSettings.FileName = "CSVFile";
                rgBranchQueriesAudit.ExportSettings.OpenInNewWindow = true;
                rgBranchQueriesAudit.ExportSettings.ExportOnlyData = true;
                rgBranchQueriesAudit.ExportSettings.IgnorePaging = true;
                rgBranchQueriesAudit.MasterTableView.GetColumn("Comment2").Display = true; // show the column when exporting
                rgBranchQueriesAudit.MasterTableView.ExportToCSV();
            }
            else
            {

            }
        }

        protected void lbtElementRef_Click(object sender, EventArgs e)
        {
            LinkButton lbt = sender as LinkButton;
            //remove the /1 after element ref to get the booking ref
            string url = lbt.Text.Substring(0,lbt.Text.IndexOf('/')).GetBookingViewerLink(true);
            winBookingViewer.NavigateUrl = url;
            string cid = winBookingViewer.ClientID;
            string script = "function f(){$find(\"" + cid + "\").show(); Sys.Application.remove_load(f);}Sys.Application.add_load(f);";

            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "ShowBkgViewer", script, true);
        }

        protected void rgBranchQueries_DataBound(object sender, EventArgs e)
        {
            colourcommentBox(1);
        }

        protected void rgHeadOfficeView_DataBound(object sender, EventArgs e)
        {
            colourcommentBox(2);
        }
    }
}