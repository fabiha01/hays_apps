﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.ServiceModel.Description;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Xrm;
using System.Data.SqlClient;
using System.Data;

namespace Apps.SPAM
{
    public partial class CreateSupplier : System.Web.UI.Page
    {
        private string cstr = System.Configuration.ConfigurationManager.ConnectionStrings["cstrDW1-DWADMIN2"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            //using (HaysTravelLtd_MSCRMEntities CRM = new HaysTravelLtd_MSCRMEntities())
            //{
            //    if (!Page.IsPostBack)
            //    {
            //        //Bind Legal entities
            //        var le = CRM.joy_cvmlegalentity.Where(x => x.statecode == 0).Select(x => new { x.joy_name, x.joy_cvmlegalentityId });
            //        selLegalEntity.DataSource = le.ToList();
            //        selLegalEntity.DataValueField = "joy_cvmlegalentityid";
            //        selLegalEntity.DataTextField = "joy_name";
            //        selLegalEntity.DataBind();

            //        //Bind Payment Demand
            //        var pd = CRM.StringMaps.Where(x => x.AttributeName == "Joy_paymentdemand").Select(x => new { x.Value, x.AttributeValue });
            //        selPaymentDemand.DataSource = pd.ToList();
            //        selPaymentDemand.DataValueField = "AttributeValue";
            //        selPaymentDemand.DataTextField = "Value";
            //        selPaymentDemand.DataBind();

            //        //Bind Statement Frequency
            //        var sf = CRM.StringMaps.Where(x => x.AttributeName == "Joy_statementFreq").Select(x => new { x.Value, x.AttributeValue });
            //        selStatementFrequency.DataSource = sf.ToList();
            //        selStatementFrequency.DataValueField = "AttributeValue";
            //        selStatementFrequency.DataTextField = "Value";
            //        selStatementFrequency.DataBind();

            //        //Bind Date of Statement
            //        var sd = CRM.StringMaps.Where(x => x.AttributeName == "Joy_dateofstatement").Select(x => new { x.Value, x.AttributeValue });
            //        selStatementDate.DataSource = sd.ToList();
            //        selStatementDate.DataValueField = "AttributeValue";
            //        selStatementDate.DataTextField = "Value";
            //        selStatementDate.DataBind();

            //        //Bind Company
            //        var c = CRM.StringMaps.Where(x => x.AttributeName == "Joy_hayscompany").Select(x => new { x.Value, x.AttributeValue });
            //        selCompany.DataSource = c.ToList();
            //        selCompany.DataValueField = "AttributeValue";
            //        selCompany.DataTextField = "Value";
            //        selCompany.DataBind();
            //    }

            //    if (Request["__EVENTTARGET"] == "selLegalEntity")
            //    {
            //        //Bind Trading Name
            //        Guid leGuid = Guid.Parse(selLegalEntity.Value);
            //        var tn = CRM.joy_cvmtradingname.Where(x => x.statecode == 0 && x.joy_CVM_Level_1_2 == leGuid).Select(x => new { x.joy_name, x.joy_cvmtradingnameId });
            //        selTradingName.DataSource = tn.ToList();
            //        selTradingName.DataValueField = "joy_cvmtradingnameId";
            //        selTradingName.DataTextField = "joy_name";
            //        selTradingName.DataBind();
            //    }
            //    //Bind Agency Agreement
            //    if (Request["__EVENTTARGET"] == "selTradingName")
            //    {
            //        Guid tnGuid = Guid.Parse(selTradingName.Value);
            //        var aa = CRM.joy_cvmagencyagreement.Where(x => x.statecode == 0 && x.joy_CVM_Level_2_3 == tnGuid).Select(x => new { x.joy_name, x.joy_cvmagencyagreementId });
            //        selAgencyAgreement.DataSource = aa.ToList();
            //        selAgencyAgreement.DataValueField = "joy_cvmagencyagreementId";
            //        selAgencyAgreement.DataTextField = "joy_name";
            //        selAgencyAgreement.DataBind();

            //        joy_cvmtradingname tName = CRM.joy_cvmtradingname.Where(x => x.joy_cvmtradingnameId == tnGuid).FirstOrDefault();
            //        selPaymentDemand.Value = tName.joy_PaymentDemand.ToString();
            //        selStatementFrequency.Value = tName.joy_StatementFreq.ToString();
            //        selStatementDate.Value = tName.joy_DateofStatement.ToString();
            //        inputPaymentTerms.Value = tName.joy_PaymentTerms.ToString();
            //        chkRefunds.Checked = (bool)tName.joy_AllowRefunds;
            //    }

            //    if (selAgencyAgreement.Items.Count > 0)
            //    {
            //        inputSupplier.Value = selTradingName.Items[selTradingName.SelectedIndex].Text;

            //        Guid aaGuid = Guid.Parse(selAgencyAgreement.Value);
            //        var aa = CRM.joy_cvmagencyagreement.Where(x => x.joy_cvmagencyagreementId == aaGuid).FirstOrDefault();
            //        selCompany.Value = aa.joy_HaysCompany.ToString();
            //    }
            //}
        }

        //protected void CmbCentralVendor_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    using (HaysTravelLtd_MSCRMEntities CRM = new HaysTravelLtd_MSCRMEntities())
        //    {
        //        //Get entity from combobox
        //        //Parse guid as Linq does not like the method in a lambda
        //        Guid tnid = Guid.Parse(CmbCentralVendor.SelectedValue);
        //        var tradingname = CRM.joy_cvmtradingname.Where(tn => tn.joy_cvmtradingnameId == tnid).FirstOrDefault();

        //        if (tradingname != null)
        //        {
        //            inputSupplier.Value = tradingname.joy_name;
        //            selPaymentDemand.Value = tradingname.joy_PaymentDemand.ToString();
        //            selStatementFrequency.Value = tradingname.joy_StatementFreq.ToString();
        //            selStatementDate.Value = tradingname.joy_DateofStatement.ToString();
        //            inputPaymentTerms.Value = tradingname.joy_PaymentTerms.ToString();
        //            chkRefunds.Checked = (bool)tradingname.joy_AllowRefunds;

        //            //Bind agency Param
        //            CentralVendorAgencyAgreement.SelectParameters["tNameID"].DefaultValue = CmbCentralVendor.SelectedValue;

        //            CmbAgencyAgreement.DataBind();

        //        }
        //    }
        //}

        //protected void btnSubmit_Click(object sender, EventArgs e)
        //{
            //using (OrganizationServiceProxy crmService = getCrmService())
            //{
            //    //Update Trading Name
            //    //if it exists update
            //    if (!string.IsNullOrEmpty(selTradingName.Value))
            //    {
            //        Entity tName = crmService.Retrieve("joy_cvmtradingname", Guid.Parse(selTradingName.Value), new ColumnSet(true));
            //        tName["joy_name"] = inputSupplier.Value;
            //        tName["joy_paymentdemand"] = new OptionSetValue(int.Parse(selPaymentDemand.Value));
            //        tName["joy_statementfreq"] = new OptionSetValue(int.Parse(selStatementFrequency.Value));
            //        tName["joy_dateofstatement"] = new OptionSetValue(int.Parse(selStatementDate.Value));
            //        tName["joy_paymentterms"] = int.Parse(inputPaymentTerms.Value);
            //        tName["joy_allowrefunds"] = chkRefunds.Checked;

            //        crmService.Update(tName);

            //        QueryExpression qe = new QueryExpression("joy_cvmagencyagreement");
            //        qe.ColumnSet = new ColumnSet(true);
            //        FilterExpression fe = new FilterExpression();
            //        ConditionExpression cond = new ConditionExpression("joy_hayscompany", ConditionOperator.Equal, selCompany.Value);
            //        ConditionExpression cond1 = new ConditionExpression("joy_cvm_level_2_3", ConditionOperator.Equal, tName.Id);
            //        fe.Conditions.Add(cond);
            //        fe.Conditions.Add(cond1);
            //        qe.Criteria.AddFilter(fe);

            //        EntityCollection Collection = crmService.RetrieveMultiple(qe);

            //        if (Collection.Entities.Count == 1)
            //        {
            //            Entity agAgreement = Collection.Entities[0];
            //            agAgreement["joy_hayscompany"] = new OptionSetValue(int.Parse(selCompany.Value));
            //            crmService.Update(agAgreement);
            //        }
            //        else if (Collection.Entities.Count == 0)
            //        {
            //            Entity agAgreement = new Entity("joy_cvmagencyagreement");
            //            agAgreement["joy_name"] = string.Format("{0} - {1} ({2} {3})", inputSupplier.Value, selCompany.Items[selCompany.SelectedIndex].Text, DateTime.Now.ToString("MMM", CultureInfo.CreateSpecificCulture("en-US")), DateTime.Now.Year);
            //            agAgreement["joy_hayscompany"] = new OptionSetValue(int.Parse(selCompany.Value));
            //            agAgreement["joy_legalentityid"] = new EntityReference("joy_cvmlegalentity", Guid.Parse(selLegalEntity.Value));
            //            agAgreement["joy_cvm_level_2_3"] = new EntityReference("joy_cvmtradingname", tName.Id);

            //            crmService.Create(agAgreement);
            //        }
            //        else
            //        {
            //            throw new Exception("Incorrect Number Of Entities DATA ISSUE");
            //        }

            //    }
            //    //otherwise create it in CRM
            //    else
            //    {
            //        if (selLegalEntity.Value != null)
            //        {
            //            Entity tName = new Entity("joy_cvmtradingname");
            //            tName["joy_name"] = inputSupplier.Value;
            //            tName["joy_paymentdemand"] = new OptionSetValue(int.Parse(selPaymentDemand.Value));
            //            tName["joy_statementfreq"] = new OptionSetValue(int.Parse(selStatementFrequency.Value));
            //            tName["joy_dateofstatement"] = new OptionSetValue(int.Parse(selStatementDate.Value));
            //            tName["joy_paymentterms"] = int.Parse(inputPaymentTerms.Value);
            //            tName["joy_allowrefunds"] = chkRefunds.Checked;
            //            tName["joy_cvm_level_1_2"] = new EntityReference("joy_cvmlegalentity", Guid.Parse(selLegalEntity.Value));

            //            Guid tNameGuid = crmService.Create(tName);

            //            Entity agAgreement = new Entity("joy_cvmagencyagreement");
            //            agAgreement["joy_name"] = string.Format("{0} - {1} ({2} {3})", inputSupplier.Value, selCompany.Items[selCompany.SelectedIndex].Text, DateTime.Now.ToString("MMM", CultureInfo.CreateSpecificCulture("en-US")), DateTime.Now.Year);
            //            agAgreement["joy_hayscompany"] = new OptionSetValue(int.Parse(selCompany.Value));
            //            agAgreement["joy_legalentityid"] = new EntityReference("joy_cvmlegalentity", Guid.Parse(selLegalEntity.Value));
            //            agAgreement["joy_cvm_level_2_3"] = new EntityReference("joy_cvmtradingname", tNameGuid);

            //            crmService.Create(agAgreement);
            //        }
            //        else
            //        {
            //            throw new Exception("YOU NEED A LEGAL ENTITY");
            //        }
            //    }
            //}
            ////Lazy Mans Clear, probs need to add a clear in because you want some sort of feedback it was successful
            //Response.Redirect("/SPAM/CreateSupplier.aspx");
        //}


        protected void btnUpdateCRM_Click(object sender, EventArgs e)
        {
            UpdateBankAccountsInCRM();
        }

        private void UpdateBankAccountsInCRM()
        {
            Guid id;
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(cstr))
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {
                    // Get list of companies in NAV (via Data Warehouse)
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "SELECT C.Company_Name, BA.No_ FROM DW.dbo.NAV_Bank_Account BA INNER JOIN DW.dbo.DWX_Company C ON BA.Company_ID = C.Company_ID";
                    dt.Load(cmd.ExecuteReader());

                    // Connect to CRM using SDK
                    using (OrganizationServiceProxy Crm = getCrmService())
                    {
                        // Enable early bound class
                        Crm.EnableProxyTypes();

                        // Iterate through bank accounts
                        foreach (DataRow row in dt.Rows)
                        {
                            // Query CRM entity to see if it's already in there
                            QueryExpression q = new QueryExpression
                            {
                                EntityName = joy_navbankaccount.EntityLogicalName,
                                ColumnSet = new ColumnSet("joy_navcompany", "joy_bankaccountnavid"),
                                Criteria = new FilterExpression
                                {
                                    Conditions =
                                {
                                    new ConditionExpression
                                    {
                                        AttributeName = "joy_navcompany",
                                        Operator = ConditionOperator.Equal,
                                        Values = {row["Company_Name"].ToString()}
                                    },
                                    new ConditionExpression
                                    {
                                        AttributeName = "joy_bankaccountnavid",
                                        Operator = ConditionOperator.Equal,
                                        Values = {row["No_"].ToString()}
                                    }
                                }
                                }
                            };

                            DataCollection<Entity> bankAccounts = Crm.RetrieveMultiple(q).Entities;
                            if (bankAccounts.Count == 0) // If it's not already in there...
                            {
                                // ... add it as a new NAV Bank Account entity
                                joy_navbankaccount newBA = new joy_navbankaccount();
                                newBA.joy_name = row["No_"].ToString() + " (" + row["Company_Name"].ToString() + ")";
                                newBA.joy_NAVCompany = row["Company_Name"].ToString();
                                newBA.joy_BankAccountNAVID = row["No_"].ToString();
                                id = Crm.Create(newBA);
                            }
                        }


                    }
                }
            }
        }

        private static OrganizationServiceProxy getCrmService()
        {
            ClientCredentials clientCredentials = new ClientCredentials();
            clientCredentials.Windows.ClientCredential.UserName = "nav.crm";
            clientCredentials.Windows.ClientCredential.Password = "ultimaseries2";
            clientCredentials.Windows.ClientCredential.Domain = "Haystravel";

            Uri serviceUri = new Uri("http://htcrm:5555/haystravel/Xrmservices/2011/organization.svc");
            OrganizationServiceProxy Crm = new OrganizationServiceProxy(serviceUri, null, clientCredentials, clientCredentials);

            return Crm;
        }

        //protected void CmbAgencyAgreement_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    using (HaysTravelLtd_MSCRMEntities CRM = new HaysTravelLtd_MSCRMEntities())
        //    {
        //        Guid aaGuid = Guid.Parse(selAgencyAgreement.Value);
        //        var agencyagreement = CRM.joy_cvmagencyagreement.Where(aa => aa.joy_cvmagencyagreementId == aaGuid).FirstOrDefault();
        //        if (agencyagreement != null)
        //        {
        //            selCompany.Value = agencyagreement.joy_HaysCompany.ToString();
        //        }
        //    }
        //}
    }
}