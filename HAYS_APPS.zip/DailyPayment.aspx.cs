﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data;
using Telerik.Web.UI;

namespace Apps.SPAM
{
    public partial class DailyPayment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblError.Visible = false;
            lblSavedSuccessfully.Visible = false;
            //show control from the qurey string
            if (Request.QueryString["DPSS"] == "1")
            {
                lblTitle.Text = "SPAM: Daily Payment Supplier Setup";
                lblCompany.Text = "Company:";
                lblCompany.Visible = true;
                ddlCompany.Visible = true;
                ddlSupplierType.Visible = true;
                lblSupplierType.Text = "Supplier Type:";
                lblSupplierType.Visible = true;
                btnSave.Visible = true;
               if(!Page.IsPostBack)
               {
                    mvwDailyPayment.ActiveViewIndex = 0;
               }
                   
            }
            else 
            {

                lblTitle.Text = "SPAM: Daily Payment";
                lblCompany.Text = "Company:";
                lblCompany.Visible = true;
                ddlCompany.Visible = true;
                lblSupplier.Text = "Supplier:";
                lblSupplier.Visible = true;
                ddlSupplier.Visible = true;
                //btnPay.Visible = true;

                ChangeColumnsDailyPayment();    

                mvwDailyPayment.ActiveViewIndex = 1;

            }
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
               //saved the data to database
                SavedDailyPaymentSupplierSetup();

                //rebind the grid
                //LoadDailyPaymentSupplierSetup();

                lblSavedSuccessfully.Text = "Saved Successfully";
                lblSavedSuccessfully.Visible = true;
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }

        }

        private void ChangeColumnsDailyPayment()
        {
            //shows depends on comapny selected
            if (ddlCompany.SelectedValue == "")
            {
                rgDailyPayment.Columns[9].Visible = true;
                rgDailyPayment.Columns[10].Visible = true;
                //
                rgDailyPayment.Columns[12].Visible = true;
                rgDailyPayment.Columns[13].Visible = false;
                //
                rgDailyPayment.Columns[16].Visible = true;
                //
                rgDailyPayment.Columns[17].Visible = false;
                //
                rgDailyPayment.Columns[19].Visible = true;
                //itour
                rgDailyPayment.Columns[20].Visible = false;
                rgDailyPayment.Columns[21].Visible = false;
                rgDailyPayment.Columns[22].Visible = false;
                rgDailyPayment.Columns[23].Visible = false;
                rgDailyPayment.Columns[24].Visible = false;

            }
            else if (ddlCompany.SelectedValue == "1")
            {
                rgDailyPayment.Columns[9].Visible = true;
                rgDailyPayment.Columns[10].Visible = false;
                rgDailyPayment.Columns[13].Visible = false;
                rgDailyPayment.Columns[12].Visible = true;
                rgDailyPayment.Columns[16].Visible = true;
                rgDailyPayment.Columns[17].Visible = false;
                rgDailyPayment.Columns[19].Visible = true;
                rgDailyPayment.Columns[20].Visible = false;
                rgDailyPayment.Columns[21].Visible = false;
                rgDailyPayment.Columns[22].Visible = false;
                rgDailyPayment.Columns[23].Visible = false;
                rgDailyPayment.Columns[24].Visible = false;
            }
            else
            {
                rgDailyPayment.Columns[9].Visible = true;
                rgDailyPayment.Columns[10].Visible = true;
                rgDailyPayment.Columns[11].Visible = true;
                rgDailyPayment.Columns[12].Visible = true;
                rgDailyPayment.Columns[13].Visible = true;
                rgDailyPayment.Columns[16].Visible = true;
                rgDailyPayment.Columns[17].Visible = true;
                rgDailyPayment.Columns[19].Visible = true;
                rgDailyPayment.Columns[20].Visible = true;
                rgDailyPayment.Columns[21].Visible = true;
                rgDailyPayment.Columns[22].Visible = true;
                rgDailyPayment.Columns[23].Visible = true;
                rgDailyPayment.Columns[24].Visible = true;
            }
        }

        private void SavedDailyPaymentSupplierSetup()
        {
            foreach (GridItem row in rgDailyPaymentSupplierSetup.Items)
            {
                Label lblSupplierID = row.FindControl("lblSupplierID") as Label;
                CheckBox cbxDailyPayment = row.FindControl("cbxDailyPayment") as CheckBox;

                using (SqlConnection conn = new SqlConnection())
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Parameters.Clear();

                        conn.ConnectionString = (string)Session["conDWADMIN2"];
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Connection = conn;

                        cmd.CommandText = "usp_APPS_SPAM_Update_Daily_Payment_Supplier_Setup";

                        conn.Open();

                        if(cbxDailyPayment.Checked == true)
                        {
                            SqlParameter pDailyPayment = cmd.Parameters.Add("@DailyPayment", SqlDbType.Bit);
                            pDailyPayment.Direction = ParameterDirection.Input;
                            pDailyPayment.Value = true;
                        }
                        else
                        {
                            SqlParameter pDailyPayment = cmd.Parameters.Add("@DailyPayment", SqlDbType.Bit);
                            pDailyPayment.Direction = ParameterDirection.Input;
                            pDailyPayment.Value = false;
                        }
     
                        SqlParameter pSupplierID = cmd.Parameters.Add("@SupplierID", SqlDbType.Int);
                        pSupplierID.Direction = ParameterDirection.Input;
                        pSupplierID.Value = Convert.ToInt32(lblSupplierID.Text);

                        cmd.ExecuteNonQuery();

                        conn.Close();
                    }
                }
            }
        }

        protected void rtDailyPayment_ButtonClick(object sender, RadToolBarEventArgs e)
        {
            RadToolBarButton btn = e.Item as RadToolBarButton;

            if (btn.CommandName == "ExportToExcel")
            {
                rgDailyPayment.ExportSettings.FileName = "ExportedFile";
                rgDailyPayment.ExportSettings.Excel.Format = (GridExcelExportFormat)Enum.Parse(typeof(GridExcelExportFormat), "Xlsx");
                rgDailyPayment.ExportSettings.IgnorePaging = true;
                rgDailyPayment.ExportSettings.ExportOnlyData = true;
                rgDailyPayment.ExportSettings.OpenInNewWindow = true;
                rgDailyPayment.MasterTableView.ExportToExcel();
            }
        }
    }
}
