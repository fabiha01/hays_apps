﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Apps.SPAM
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            using (SpamEntities spam = new SpamEntities())
            {
                var knownBugs = spam.SPM_Update_Status.Where(x => x.Type == 1 && x.Visible == true).OrderBy(x => x.Priority);

                string bugs = "";
                foreach(SPM_Update_Status bug in knownBugs)
                {
                    bugs += string.Format("{0}. {1} - {2}\n\n", bug.Priority, bug.DateLogged, bug.Text);
                }
                txtKnownBugs.Text = bugs;

                var latestUpdates = spam.SPM_Update_Status.Where(x => x.Type == 2 && x.Visible == true).OrderByDescending(x => x.DateLogged);

                string updates = "";
                foreach (SPM_Update_Status update in latestUpdates)
                {
                    updates += string.Format("{0}. {1} - {2}\n\n", update.Priority, update.DateLogged, update.Text);
                    lblUpdates.Text = string.Format("Latest Updates: Version {0}", update.Version);
                }
                txtLatestUpdates.Text = updates;
            }


        }

        protected void gvwXMLImportMointor_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            // colour the traffic lights 
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                int GetValue = Convert.ToInt32(e.Row.Cells[8].Text);
                string SetColourClass = string.Empty;
                if (GetValue == 0)
                {
                    e.Row.Cells[8].BackColor = System.Drawing.Color.Green;
                    e.Row.Cells[8].Text = "";
                }
                else
                {
                    e.Row.Cells[8].BackColor = System.Drawing.Color.Red;
                    e.Row.Cells[8].Text = "";
                }


            }
        }
    }
}