﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data;
using Microsoft.Reporting.WebForms;
using System.Net;
using Telerik.Web.UI;

namespace Apps.SPAM
{
    public partial class FileNotLoaded : System.Web.UI.Page
    {
        SqlGuid sqlguid;
        Guid aaGuid;
        string branchcode;
        DataTable datatable = new DataTable();
        string comment;
        string sUsername;
        int n;
        int iGridView;
        int ireportview;
        DateTime DateLoaded;
        DateTime DateFunded;
        DateTime TestDate;
        Boolean ManagerAccess;

        protected void Page_Load(object sender, EventArgs e)
        {
            cbxClose.InputAttributes.Add("data-toggle","toggle");
            cbxClose.InputAttributes.Add("data-off", "Open");
            cbxClose.InputAttributes.Add("data-on","Closed");
            cbxClose.InputAttributes.Add("AutoPostBack", "true");
            cbxClose.InputAttributes.Add("data-offstyle", "primary");
            cbxClose.InputAttributes.Add("data-onstyle", "warning");

            // to get the username for the session varaible for the comments
            if (Session["Username"] != null)
            {
                sUsername = Session["Username"].ToString();

                if (int.TryParse(sUsername, out n) == true)
                {
                    //add a 0 to username with only 00
                    if (sUsername.Length == 3)
                    {
                        sUsername = "0" + sUsername;

                    }
                }
            }

            // the File Not loaded
            if (Request.QueryString["FileNotLoaded"] == "1")
            {
                lblTitle.Text = "SPAM: Supplier Payment File Not Loaded";
                iGridView = 1;
                ireportview = 1;

                lblInfo.Visible = false;

                    using (HaysTravelLtd_MSCRMEntities CRM = new HaysTravelLtd_MSCRMEntities())
                    {
                        if (!Page.IsPostBack)
                        {
                            var tn = CRM.joy_cvmtradingname.Where(x => x.statecode == 0).Select(x => new { x.joy_name, x.joy_cvmtradingnameId });
                            selTradingName.DataSource = tn.ToList();
                            selTradingName.DataValueField = "joy_cvmtradingnameId";
                            selTradingName.DataTextField = "joy_name";
                            selTradingName.DataBind();
                            selTradingName.Items.Insert(0, "Please Select a Trading Name");

                        }

                       
                    }

                if (Request["__EVENTTARGET"] == "selTradingName")
                {
                    //Filter Trading Name
                    if (selTradingName.Value != "Please Select a Trading Name")
                    {
                        Guid leGuid = Guid.Parse(selTradingName.Value);
                    }

                    LoadGrid(selTradingName.Value, selBranchCode.Value, iGridView);
                    ColourGrid(1);

                }

                using (SpamEntities spam = new SpamEntities())
                    {
                        if (!Page.IsPostBack)
                        {
                            var br = spam.DWX_Branch.Where(x => x.BranchName != "Unknown").Select(x => new { Branchname = x.BranchID + "-" + x.BranchName, x.BranchID });
                            selBranchCode.DataSource = br.ToList();
                            selBranchCode.DataValueField = "BranchID";
                            selBranchCode.DataTextField = "BranchName";
                            selBranchCode.DataBind();
                            selBranchCode.Items.Insert(0, "Please Select a Branch");

                        }

                        if (Request["__EVENTTARGET"] == "selBranchCode")
                        {
                            if (selBranchCode.Value != "Please Select a Branch")
                            {
                                branchcode = selBranchCode.Value;

                                branchcode = spam.DWX_Branch.Where(x => x.BranchID == branchcode).Select(x => x.BranchID + "-" + x.BranchName).FirstOrDefault();
                                selBranchCode.Value = branchcode;

                                LoadGrid(selTradingName.Value, selBranchCode.Value, iGridView);
                                ColourGrid(1);
                            }
                            else
                            {
                                var br = spam.DWX_Branch.Where(x => x.BranchName != "Unknown").Select(x => new { Branchname = x.BranchID + "-" + x.BranchName, x.BranchID });
                                selBranchCode.DataSource = br.ToList();
                                selBranchCode.DataValueField = "BranchID";
                                selBranchCode.DataTextField = "BranchName";
                                selBranchCode.DataBind();
                                selBranchCode.Items.Insert(0, "Please Select a Branch");

                                LoadGrid(selTradingName.Value, selBranchCode.Value, iGridView);
                                ColourGrid(1);
                            }

                        }
                    }
                
                if(!Page.IsPostBack)
                {
                    LoadGrid(selTradingName.Value, selBranchCode.Value, iGridView);
                    ColourGrid(1);

                    if (Session["ManagerAccess"] != null)
                    {
                        ManagerAccess = Convert.ToBoolean(Session["ManagerAccess"]);

                        // if manager access is true show the columns 
                        if(ManagerAccess)
                        {
                            rgManagerViewFileNotLoaded.Columns[16].Visible = false;
                        }
                        else
                        {
                            rgManagerViewFileNotLoaded.Columns[16].Visible = true;

                        }
                    }
                }
                
                mvwFileNotLoaded.ActiveViewIndex = 0;

                // hide the control 
                lblMonth.Visible = false;
                txtFromDate.Visible = false;
                txtToDate.Visible = false;
                spFromDateIcon.Visible = false;
                spToDateIcon.Visible = false;
            }
            // Internal Audit File not loaded  
            else if (Request.QueryString["SupplierPaymentAudit"] == "1")
            {
                lblTitle.Text = "SPAM: Internal Audit File Not Loaded";
                mvwFileNotLoaded.ActiveViewIndex = 1;
                // hide the control
                lblMonth.Visible = false;
                lblBranchCode.Visible = false;
                lblStatementName.Visible = false;        
                txtFromDate.Visible = false;
                txtToDate.Visible = false;
                selBranchCode.Visible = false;
                selTradingName.Visible = false;
                spFromDateIcon.Visible = false;
                spToDateIcon.Visible = false;
                btnRun.Visible = false;
                btnUpdateAuditBranchQueries.Visible = false;
            
                iGridView = 3;
                // post back to add a close data into the txtclosedate
                cbxClose_CheckedChanged(sender, e);
           
                LoadGrid("Please Select a Trading Name", "Please Select a Branch", iGridView);
            }
            else
            {
                if(!Page.IsPostBack)
                {
                    lblTitle.Text = "SPAM: Internal Audit File Not Loaded Report";
                    mvwFileNotLoaded.ActiveViewIndex = 2;
                    // hide the control
                    lblMonth.Visible = true;
                    lblBranchCode.Visible = true;
                    lblBranchCode.Text = "To Date: ";
                    lblStatementName.Visible = false;
                    selBranchCode.Visible = false;
                    selTradingName.Visible = false;
                    lblSavedSuccessfully.Visible = false;
                    rgFileNotLoadedReport.Visible = true;
                    btnUpdateAuditBranchQueries.Visible = false;

              
                }
                // add years to drop down list 
               
                ireportview = 2;  
            }
        }
        protected void btnRun_Click(object sender, EventArgs e)
        {
            lblError.Visible = false;
            try
            {
                // loaded file not loaded for supply payment staff and report load 
                if (ireportview == 1)
                {
                    LoadGrid(selTradingName.Value, selBranchCode.Value, iGridView);
                    
                }
                else
                {
                    lblError.Visible = false;
                    if(DateTime.TryParse(txtFromDate.Text,out TestDate) == false)
                    {
                        lblError.Text = "Invaild From Date";
                        lblError.Visible = true;
                    }
                    else if(DateTime.TryParse(txtToDate.Text, out TestDate) == false)
                    {
                        lblError.Text = "Invaild To Date";
                        lblError.Visible = true;
                    }
                    else
                    {
                        ReportLoad(txtFromDate.Text, txtToDate.Text);
                    }
                    
                        
                    

                }
            }
            catch(Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }

        // load the grid 
        private void LoadGrid(string spTradingName, string spBranchID, int ipGridView)
        {
            
            lblError.Visible = false;
            lblSavedSuccessfully.Visible = false;
            // pass sptradingname as a guid 
            if (spTradingName != "Please Select a Trading Name")
            {
                sqlguid = new SqlGuid(spTradingName);
            }

            if (iGridView == 1)
            {
                if (spTradingName == "Please Select a Trading Name")
                {
                    sslDDLSupplierPaymentFileNotLoaded.SelectParameters[0].DefaultValue= null;
                }
                else
                {
                    sslDDLSupplierPaymentFileNotLoaded.SelectParameters[0].DefaultValue = spTradingName;
                }

                if (spBranchID == "Please Select a Branch")
                {
                    sslDDLSupplierPaymentFileNotLoaded.SelectParameters[1].DefaultValue = "Please Select a Branch";
                }
                else
                {
                    sslDDLSupplierPaymentFileNotLoaded.SelectParameters[1].DefaultValue = spBranchID;
                }

                //sslDDLSupplierPaymentFileNotLoaded.SelectParameters[2].DefaultValue = spSortExpression;
                //sslDDLSupplierPaymentFileNotLoaded.SelectParameters[3].DefaultValue = spSortDirection;

                //rgManagerViewFileNotLoaded.DataSource = sslDDLSupplierPaymentFileNotLoaded;
                rgManagerViewFileNotLoaded.DataBind();

                if (rgManagerViewFileNotLoaded.Items.Count == 0)
                {
                    lblInfo.Text = "No Supplier Payment File not Loaded";
                    lblInfo.Visible = true;
                    rgManagerViewFileNotLoaded.Visible = false;
                }
                else
                {
                    rgManagerViewFileNotLoaded.Visible = true;
                }
            }
            else
            {
                //sslDDlInternalAuditFileNotLoadead.SelectParameters[0].DefaultValue = spSortExpression;
                //sslDDlInternalAuditFileNotLoadead.SelectParameters[1].DefaultValue = spSortDirection;

                //rgInternalAuditFileNotLoaded.DataSource = sslDDlInternalAuditFileNotLoadead;
                rgInternalAuditFileNotLoaded.DataBind();
                ColourGrid(2);
            }
        }

        private void LoadInternalAuditGrid(string spSortExpression, string spSortDirection)
        {

            lblError.Visible = false;
            lblSavedSuccessfully.Visible = false;
                 
            //sslDDlInternalAuditFileNotLoadead.SelectParameters[0].DefaultValue = spSortExpression;
            //sslDDlInternalAuditFileNotLoadead.SelectParameters[1].DefaultValue = spSortDirection;

            //rgInternalAuditFileNotLoaded.DataSource = sslDDlInternalAuditFileNotLoadead;
            rgInternalAuditFileNotLoaded.DataBind();
            ColourGrid(2);
         
        }

        // colour the grid 
        private void ColourGrid(int colourgrid)
        {
            if (colourgrid == 1)
            {
                using (SpamEntities spam = new SpamEntities())
                {
                    foreach (GridDataItem row in rgManagerViewFileNotLoaded.Items)
                    {
                        Label lblStatementLineID = row.FindControl("lblStatementLineID") as Label;
                        int sline = Convert.ToInt32(lblStatementLineID.Text);

                        SPM_Statement_Lines line = spam.SPM_Statement_Lines.Where(x => x.StatementLineID == sline).FirstOrDefault();

                        var cmts = spam.SPM_Comments.Where(x => x.ObjectKey == line.StatementLineID && x.DeletedFlag == false);
                        var qrts = spam.SPM_Queries.Where(x => x.StatementLineID == line.StatementLineID);

                        if (cmts.Count() > 0 || qrts.Count() > 0)
                        {
                            LinkButton lnkComment = row.FindControl("lntComment") as LinkButton;
                            lnkComment.ForeColor = System.Drawing.Color.DarkOrange;
                        }

                    }
                }
            }
            else
            {
                using (SpamEntities spam = new SpamEntities())
                {
                    foreach (GridItem row in rgInternalAuditFileNotLoaded.Items)
                    {
                        Label lblFileNotLoadedID = row.FindControl("lblFileNotLoadedID") as Label;

                        int sline = Convert.ToInt32(lblFileNotLoadedID.Text);

                        SPM_Statement_Lines line = spam.SPM_Statement_Lines.Where(x => x.StatementLineID == sline).FirstOrDefault();

                        var cmts = spam.SPM_Comments.Where(x => x.ObjectKey == line.StatementLineID && x.DeletedFlag == false && x.CommentType==3);
                        var qrts = spam.SPM_File_Not_Loaded.Where(x => x.StatementLineID == line.StatementLineID);

                        if (cmts.Count() > 0 || qrts.Count() > 0)
                        {
                            LinkButton lnkComment = row.FindControl("lntComment") as LinkButton;
                            lnkComment.ForeColor = System.Drawing.Color.DarkOrange;
                        }

                    }
                }
            }
        }
    
       private void ReportLoad(string FromDate , string ToDate)
        {
           
       }

        protected void btnUpdateAuditBranchQueries_Click(object sender, EventArgs e)
        {
            try
            {
                SaveAction(0);
                ColourGrid(2);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
            
        }

        protected void btnUpdateDetails_Click(object sender, EventArgs e)
        {
            if (cbxClose.Checked )
            {
                //to check if the internal audit status and if if any of this then dont closed the query
                if (ddlInternalAuditStatus.SelectedValue == "5")
                {
                    lblErrorInternalAuditSupplierDetail.Text = "Booking is in dispute!";
                    lblErrorInternalAuditSupplierDetail.Visible = true;
                }
                else if (ddlInternalAuditStatus.SelectedValue == "6")
                {
                    lblErrorInternalAuditSupplierDetail.Text = "Awaiting Supplier Response!";
                    lblErrorInternalAuditSupplierDetail.Visible = true;
                }
                else if (ddlInternalAuditStatus.SelectedValue == "7")
                {
                    lblErrorInternalAuditSupplierDetail.Text = "Awaiting Branch Response!";
                    lblErrorInternalAuditSupplierDetail.Visible = true;
                }
                else if (ddlInternalAuditStatus.SelectedValue == "8")
                {
                    lblErrorInternalAuditSupplierDetail.Text = "Awaiting Supplier Payment Response!";
                    lblErrorInternalAuditSupplierDetail.Visible = true;
                }

                else if (ddlInternalAuditStatus.SelectedValue == "9")
                {
                    lblErrorInternalAuditSupplierDetail.Text = "Invoice Needed!";
                    lblErrorInternalAuditSupplierDetail.Visible = true;
                }
                if (ddlFundType.SelectedValue == "0")
                {
                    lblErrorInternalAuditSupplierDetail.Text = "Select a Fund Type";
                    lblErrorInternalAuditSupplierDetail.Visible = true;
                }
                else if (ddlBookingMethod.SelectedValue == "0")
                {
                    lblErrorInternalAuditSupplierDetail.Text = "Select a Booking Method";
                    lblErrorInternalAuditSupplierDetail.Visible = true;
                }
                else if (ddlInternalAuditStatus.SelectedValue == "0")
                {
                    lblErrorInternalAuditSupplierDetail.Text = "Select a Internal Audit Status";
                    lblErrorInternalAuditSupplierDetail.Visible = true;
                }
                else if (txtDateFunded.Text == "")
                {
                    lblErrorInternalAuditSupplierDetail.Text = "Date Funded can't be blank";
                    lblErrorInternalAuditSupplierDetail.Visible = true;
                }
                else if (DateTime.TryParse(txtDateFunded.Text, out DateFunded) == false)
                {
                    lblErrorInternalAuditSupplierDetail.Text = "Date Funded not a vaild date";
                    lblErrorInternalAuditSupplierDetail.Visible = true;
                }
                else if (txtDateFunded.Text.Length != 10)
                {
                    lblErrorInternalAuditSupplierDetail.Text = "Date Funded not a vaild date. It should be dd/MM/yyyy";
                    lblErrorInternalAuditSupplierDetail.Visible = true;
                }
                else if (DateTime.TryParse(txtSupplierBookingDateDetail.Text, out DateFunded) == false)
                {
                    lblErrorInternalAuditSupplierDetail.Text = "Supplier Booking Date not a vaild date";
                    lblErrorInternalAuditSupplierDetail.Visible = true;
                }
                else if (txtSupplierBookingDateDetail.Text.Length != 10)
                {
                    lblErrorInternalAuditSupplierDetail.Text = "Supplier Booking Date not a vaild date. It should be dd/MM/yyyy";
                    lblErrorInternalAuditSupplierDetail.Visible = true;
                }
                else if (hidComment.Value == "")
                {
                    lblErrorInternalAuditSupplierDetail.Text = "Please enter a comment!";
                    lblErrorInternalAuditSupplierDetail.Visible = true;
                }

                else if (string.IsNullOrEmpty(txtChangesMade.Text))
                {
                    lblWarningChangesMade.Text = "Please enter a comment!!";
                    lblWarningChangesMade.Visible = true;
                    txtChangesMade.Visible = true;

                }

                else if (txtChangesMade.Text != "")
                {
                   // SaveAction(1);
                    //SavedBranchQueries(1);
                    SaveAction(1);
                    ColourGrid(2);
                    popupInternalAuditFileNotLoadedDetails.Attributes["class"] = "lbpopuph";
                    overlayInternalAuditFileNotLoadedDetails.Attributes["class"] = "lboverlayh";

                    lblSavedSuccessfully.Text = "Saved Successfully for Supplier Ref: " + hidSupplierRefInternalAuditSupplierDetails.Value + " and Lead Passenger: " + hidLeadPassengerInternalAuditSupplierDetails.Value;
                    lblSavedSuccessfully.Visible = true;

                    lblWarningChangesMade.Visible = false;
                    txtChangesMade.Visible = false;
                    txtChangesMade.Text = "";

                }

                else if (hidComment.Value.StartsWith(DateTime.Now.ToString("d")))
                {
                    //check comment has today's date and time stamp                           
                        try
                        {
                            SaveAction(1);
                            ColourGrid(2);
                            popupInternalAuditFileNotLoadedDetails.Attributes["class"] = "lbpopuph";
                            overlayInternalAuditFileNotLoadedDetails.Attributes["class"] = "lboverlayh";

                            lblSavedSuccessfully.Text = "Saved Successfully for Supplier Ref: " + hidSupplierRefInternalAuditSupplierDetails.Value + " and Lead Passenger: " + hidLeadPassengerInternalAuditSupplierDetails.Value;
                            lblSavedSuccessfully.Visible = true;
                        }
                        catch (Exception ex)
                        {
                            lblErrorInternalAuditSupplierDetail.Text = ex.Message;
                            lblErrorInternalAuditSupplierDetail.Visible = true;
                        }
                    

                }
                else
                {
                    lblErrorInternalAuditSupplierDetail.Text = "Please enter a comment!";
                    lblErrorInternalAuditSupplierDetail.Visible = true;
                }
            }

            else if (string.IsNullOrEmpty(txtChangesMade.Text))
            {
                lblWarningChangesMade.Text = "Please enter a comment!";
                lblWarningChangesMade.Visible = true;
                txtChangesMade.Visible = true;
            }

            else if(txtChangesMade.Text != "")
            {
               // SaveAction(1);
                SaveAction(1);
                ColourGrid(2);
                popupInternalAuditFileNotLoadedDetails.Attributes["class"] = "lbpopuph";
                overlayInternalAuditFileNotLoadedDetails.Attributes["class"] = "lboverlayh";

                lblSavedSuccessfully.Text = "Saved Successfully for Supplier Ref: " + hidSupplierRefInternalAuditSupplierDetails.Value + " and Lead Passenger: " + hidLeadPassengerInternalAuditSupplierDetails.Value;
                lblSavedSuccessfully.Visible = true;

                lblWarningChangesMade.Visible = false;
                txtChangesMade.Visible = false;
                txtChangesMade.Text = "";

            }
            else
            {
                try
                {
                    SaveAction(1);
                    ColourGrid(2);
                    popupInternalAuditFileNotLoadedDetails.Attributes["class"] = "lbpopuph";
                    overlayInternalAuditFileNotLoadedDetails.Attributes["class"] = "lboverlayh";

                    lblSavedSuccessfully.Text = "Saved Successfully for Supplier Ref: " + hidSupplierRefInternalAuditSupplierDetails.Value + " and Lead Passenger: " + hidLeadPassengerInternalAuditSupplierDetails.Value;
                    lblSavedSuccessfully.Visible = true;
                }
                catch (Exception ex)
                {
                    lblErrorInternalAuditSupplierDetail.Text = ex.Message;
                    lblErrorInternalAuditSupplierDetail.Visible = true;
                }
            }

            if (!Page.IsPostBack)
            {
                LoadDetail(1, sender);
            }
            
            ScrollToStatementLine();
        }
          
        protected void btnCloseDetails_Click(object sender, EventArgs e)
        {
            popupInternalAuditFileNotLoadedDetails.Attributes["class"] = "lbpopuph";
            overlayInternalAuditFileNotLoadedDetails.Attributes["class"] = "lboverlayh";

            lblWarningChangesMade.Visible = false;
            txtChangesMade.Visible = false;
            txtChangesMade.Text = "";
            ScrollToStatementLine();
        }
        protected void btnClose_Click(object sender, EventArgs e)
        {
            popup.Attributes["class"] = "lbpopuph";
            overlay.Attributes["class"] = "lboverlayh";
            ScrollToStatementLine();
        }

        private void SaveAction(int siCloseQueries)
        {
                lblError.Visible = false;

                SqlConnection conn = new SqlConnection();
                SqlCommand cmd = new SqlCommand();

                conn.ConnectionString = (string)Session["conDWADMIN2"];

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn;
                cmd.CommandText = "usp_APPS_SPM_Update_File_Not_loaded";

            if (iGridView == 1)
            {
                lblError.Visible = false;


                foreach (GridViewRow row in rgManagerViewFileNotLoaded.Items)
                {
                    DropDownList ddlAction = row.FindControl("ddlAction") as DropDownList;
                    Label lblStatementLineID = row.FindControl("lblStatementLineID") as Label;
                    Label lblTradingName = row.FindControl("lblTradingName") as Label;
                    Label lblSupplierRef = row.FindControl("lblSupplierRef") as Label;
                    Label lblBranchID = row.FindControl("lblBranchID") as Label;
                    Label lblObjectKey = row.FindControl("lblObjectKey") as Label;
                    TextBox txtSupplierBookingDate = row.FindControl("txtSupplierBookingdate") as TextBox;
                    TextBox txtElementRef = row.FindControl("txtElementRef") as TextBox;
           
                    cmd.Parameters.Clear();

                    // saved the element ref if the agent put it in without a reason
                    SqlParameter pQueryID = cmd.Parameters.Add("QueryID", SqlDbType.Int);
                    pQueryID.Direction = ParameterDirection.Input;
                    pQueryID.Value = Convert.ToInt32(lblObjectKey.Text);

                    SqlParameter pPassedToAudit = cmd.Parameters.Add("PassedtoAudit", SqlDbType.Int);
                    pPassedToAudit.Direction = ParameterDirection.Input;
                    pPassedToAudit.Value = 3;

                    SqlParameter pElementRef = cmd.Parameters.Add("ElementRef", SqlDbType.VarChar, 50);
                    pElementRef.Direction = ParameterDirection.Input;
                    pElementRef.Value = txtElementRef.Text;
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    LoadGrid(selTradingName.Value, selBranchCode.Value, iGridView);
                    ColourGrid(1);

                    
                     if (Convert.ToInt32(ddlAction.SelectedValue) != 2 && Convert.ToInt32(ddlAction.SelectedValue) != 0)
                     {
                        cmd.Parameters.Clear();
                        SqlParameter pAction = cmd.Parameters.Add("Action", SqlDbType.Int);
                        pAction.Direction = ParameterDirection.Input;
                        pAction.Value = Convert.ToInt32(ddlAction.SelectedValue);

                        SqlParameter pQueryID1 = cmd.Parameters.Add("QueryID", SqlDbType.Int);
                        pQueryID1.Direction = ParameterDirection.Input;
                        pQueryID1.Value = Convert.ToInt32(lblObjectKey.Text);

                        SqlParameter pPassedToAudit1 = cmd.Parameters.Add("PassedtoAudit", SqlDbType.Int);
                        pPassedToAudit1.Direction = ParameterDirection.Input;
                        pPassedToAudit1.Value = 0;

                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();

                        LoadGrid(selTradingName.Value, selBranchCode.Value, iGridView);
                        ColourGrid(1);
                     }

                    else
                    {
                        //if the manager select passed to audit
                        if (ddlAction.SelectedValue == "2")
                        {
                            if (!string.IsNullOrEmpty(txtSupplierBookingDate.Text))
                            {
                                if (DateTime.TryParse(txtSupplierBookingDate.Text, out TestDate) == false)
                                {
                                    lblError.Text = "Supplier Booking Date is not a vaild Date";
                                    lblError.Visible = true;
                                    break;
                                }
                            }
                            if (txtElementRef.Text == "")
                            {
                                lblError.Text = "Element Ref can't be blank";
                                lblError.Visible = true;
                                break;
                            }
                            else if (isvaildExtension(txtElementRef.Text.Substring(0, 3)) == false)
                            {
                                lblError.Text = "Element Ref must contain the folowing reference HAY-/HTR-/HTF-/HBD-/BUS-/MIN-/BTM-/HPL-. ";
                                lblError.Visible = true;
                                break;
                            }
                            else if (txtElementRef.Text.Contains("/") == false)
                            {
                                lblError.Text = "Element Ref does not contain a / at the end";
                                lblError.Visible = true;
                                break;
                            }
                            else if (txtElementRef.Text.Contains("-") == false)
                            {
                                lblError.Text = "Element Ref does not contain a -";
                                lblError.Visible = true;
                                break;
                            }
                            else if (int.TryParse(txtElementRef.Text.Substring(4, txtElementRef.Text.IndexOf('/') - txtElementRef.Text.IndexOf('-') - 1), out n) == false)
                            {
                                lblError.Text = "Element Ref is not a vaild Reference";
                                lblErrorInternalAuditSupplierDetail.Visible = true;
                                break;
                            }

                            else
                            {
                                cmd.Parameters.Clear();

                                sqlguid = new SqlGuid(lblTradingName.Text);

                                SqlParameter pAction = cmd.Parameters.Add("Action", SqlDbType.Int);
                                pAction.Direction = ParameterDirection.Input;
                                pAction.Value = Convert.ToInt32(ddlAction.SelectedValue);

                                SqlParameter pStatementLineID = cmd.Parameters.Add("StatementLineID", SqlDbType.Int);
                                pStatementLineID.Direction = ParameterDirection.Input;
                                pStatementLineID.Value = Convert.ToInt32(lblStatementLineID.Text);

                                SqlParameter pQueryID2 = cmd.Parameters.Add("QueryID", SqlDbType.Int);
                                pQueryID2.Direction = ParameterDirection.Input;
                                pQueryID2.Value = Convert.ToInt32(lblObjectKey.Text);

                                SqlParameter pSupplierRef = cmd.Parameters.Add("SupplierRef", SqlDbType.VarChar, 50);
                                pSupplierRef.Direction = ParameterDirection.Input;
                                pSupplierRef.Value = lblSupplierRef.Text;

                                SqlParameter pQueryType = cmd.Parameters.Add("QueryType", SqlDbType.Int);
                                pQueryType.Direction = ParameterDirection.Input;
                                pQueryType.Value = 3;

                                SqlParameter pBranchID = cmd.Parameters.Add("BranchID", SqlDbType.VarChar, 10);
                                pBranchID.Direction = ParameterDirection.Input;
                                pBranchID.Value = lblBranchID.Text;

                                SqlParameter pTradingName = cmd.Parameters.Add("TradingName", SqlDbType.UniqueIdentifier);
                                pTradingName.Direction = ParameterDirection.Input;
                                pTradingName.Value = sqlguid;

                                if (string.IsNullOrEmpty(txtSupplierBookingDate.Text))
                                {

                                    SqlParameter pSupplierBookingDate = cmd.Parameters.Add("@SupplierBookingDate", SqlDbType.Date);
                                    pSupplierBookingDate.Direction = ParameterDirection.Input;
                                    pSupplierBookingDate.Value = null;

                                }
                                else
                                {
                                    SqlParameter pSupplierBookingDate = cmd.Parameters.Add("@SupplierBookingDate", SqlDbType.Date);
                                    pSupplierBookingDate.Direction = ParameterDirection.Input;
                                    pSupplierBookingDate.Value = Convert.ToDateTime(txtSupplierBookingDate.Text);
                                }

                                SqlParameter pPassedToAudit2 = cmd.Parameters.Add("PassedtoAudit", SqlDbType.Int);
                                pPassedToAudit2.Direction = ParameterDirection.Input;
                                pPassedToAudit2.Value = 1;

                                SqlParameter pElementRef1 = cmd.Parameters.Add("ElementRef", SqlDbType.VarChar, 50);
                                pElementRef1.Direction = ParameterDirection.Input;
                                pElementRef1.Value = txtElementRef.Text;

                               

                                SqlParameter pComment = cmd.Parameters.Add("@CommentText", SqlDbType.VarChar, -1);
                                pComment.Direction = ParameterDirection.Input;
                                pComment.Value = comment;

                                if(string.IsNullOrEmpty(hidCommentIDModal.Value))
                                {
                                    SqlParameter pCommentID = cmd.Parameters.Add("@CommentID", SqlDbType.Int);
                                    pCommentID.Direction = ParameterDirection.Input;
                                    pCommentID.Value = 0;
                                }
                                else
                                {
                                    SqlParameter pCommentID = cmd.Parameters.Add("@CommentID", SqlDbType.Int);
                                    pCommentID.Direction = ParameterDirection.Input;
                                    pCommentID.Value = Convert.ToInt32(hidCommentIDModal.Value);
                                }
                               

                                conn.Open();
                                cmd.ExecuteNonQuery();
                                conn.Close();

                                LoadGrid(selTradingName.Value, selBranchCode.Value, iGridView);
                                ColourGrid(1);
                            }

                        }

                    }

                }
            }

            else
            {
                //save the lightbox from internal audit File not Loaded Details
                if (siCloseQueries == 1)
                {
                    SqlParameter pAction = cmd.Parameters.Add("Action", SqlDbType.Int);
                    pAction.Direction = ParameterDirection.Input;
                    pAction.Value = 0;

                    SqlParameter pFileNotLoadedID = cmd.Parameters.Add("@FileNotLoadedID", SqlDbType.Int);
                    pFileNotLoadedID.Direction = ParameterDirection.Input;
                    pFileNotLoadedID.Value = Convert.ToInt32(hidFileNotLoadedID.Value);

                    if (string.IsNullOrEmpty(txtSupplierBookingDateDetail.Text))
                    {
                        SqlParameter pSupplierBookingDate = cmd.Parameters.Add("SupplierBookingDate", SqlDbType.Date);
                        pSupplierBookingDate.Direction = ParameterDirection.Input;
                        pSupplierBookingDate.Value = null;
                    }
                    else
                    {
                        SqlParameter pSupplierBookingDate = cmd.Parameters.Add("SupplierBookingDate", SqlDbType.Date);
                        pSupplierBookingDate.Direction = ParameterDirection.Input;
                        pSupplierBookingDate.Value = Convert.ToDateTime(txtSupplierBookingDateDetail.Text);
                    }


                    SqlParameter pPassedToAudit = cmd.Parameters.Add("PassedtoAudit", SqlDbType.Int);
                    pPassedToAudit.Direction = ParameterDirection.Input;
                    pPassedToAudit.Value = 2;

                    if (ddlBookingMethod.SelectedValue == "0")
                    {
                        SqlParameter pBookingMethod = cmd.Parameters.Add("BookingMethod", SqlDbType.Int);
                        pBookingMethod.Direction = ParameterDirection.Input;
                        pBookingMethod.Value = 0;
                    }
                    else
                    {
                        SqlParameter pBookingMethod = cmd.Parameters.Add("BookingMethod", SqlDbType.Int);
                        pBookingMethod.Direction = ParameterDirection.Input;
                        pBookingMethod.Value = Convert.ToInt32(ddlBookingMethod.SelectedValue);
                    }

                    if (string.IsNullOrEmpty(txtDateFunded.Text))
                    {
                        SqlParameter pDateFunded = cmd.Parameters.Add("DateFunded", SqlDbType.Date);
                        pDateFunded.Direction = ParameterDirection.Input;
                        pDateFunded.Value = null;
                    }

                    else
                    {
                        SqlParameter pDateFunded = cmd.Parameters.Add("DateFunded", SqlDbType.Date);
                        pDateFunded.Direction = ParameterDirection.Input;
                        pDateFunded.Value = Convert.ToDateTime(txtDateFunded.Text);
                    }

                    if (ddlFundType.SelectedValue == "0")
                    {
                        SqlParameter pFundType = cmd.Parameters.Add("FundType", SqlDbType.Int);
                        pFundType.Direction = ParameterDirection.Input;
                        pFundType.Value = 0;
                    }
                    else
                    {
                        SqlParameter pFundType = cmd.Parameters.Add("FundType", SqlDbType.Int);
                        pFundType.Direction = ParameterDirection.Input;
                        pFundType.Value = Convert.ToInt32(ddlFundType.Text);
                    }

                    if (ddlInternalAuditStatus.SelectedValue == "0")
                    {
                        SqlParameter pInternalAuditStatus = cmd.Parameters.Add("InternalAuditStatus", SqlDbType.Int);
                        pInternalAuditStatus.Direction = ParameterDirection.Input;
                        pInternalAuditStatus.Value = null;
                    }

                    else
                    {
                        SqlParameter pInternalAuditStatus = cmd.Parameters.Add("InternalAuditStatus", SqlDbType.Int);
                        pInternalAuditStatus.Direction = ParameterDirection.Input;
                        pInternalAuditStatus.Value = Convert.ToInt32(ddlInternalAuditStatus.Text);
                    }

                    SqlParameter pClose = cmd.Parameters.Add("Close", SqlDbType.Bit);
                    pClose.Direction = ParameterDirection.Input;
                    pClose.Value = cbxClose.Checked;

                    if (txtCloseDate.Text == "")
                    {
                        SqlParameter pCloseDate = cmd.Parameters.Add("CloseDate", SqlDbType.Date);
                        pCloseDate.Direction = ParameterDirection.Input;
                        pCloseDate.Value = null;
                    }
                    else
                    {
                        SqlParameter pCloseDate = cmd.Parameters.Add("CloseDate", SqlDbType.Date);
                        pCloseDate.Direction = ParameterDirection.Input;
                        pCloseDate.Value = Convert.ToDateTime(txtCloseDate.Text);
                    }

                    SqlParameter pElementRef = cmd.Parameters.Add("ElementRef", SqlDbType.VarChar, 50);
                    pElementRef.Direction = ParameterDirection.Input;
                    pElementRef.Value = internalAuditElementRef.Value;

                    //format the comment string
                    if (txtChangesMade.Text.Trim().Length > 0)
                    {
                         comment = DateTime.Now.ToString() + " -- " + sUsername + " - " + txtChangesMade.Text.Trim();
                    }
                    else
                    {
                        comment = hidComment.Value;
                    }
                       
                    SqlParameter pComment = cmd.Parameters.Add("@CommentText", SqlDbType.VarChar, -1);
                    pComment.Direction = ParameterDirection.Input;
                    pComment.Value = comment;

                    SqlParameter pCommentID = cmd.Parameters.Add("@CommentID", SqlDbType.Int);
                    pCommentID.Direction = ParameterDirection.Input;
                    pCommentID.Value = Convert.ToInt32(hidCommentIDModal.Value);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                }

                LoadGrid("Please Select a Trading Name", "Please Select a Branch", iGridView);
                ColourGrid(2);
            }
        }
       
         private void SavedBranchQueries(int SavedID)
        {
            btnUpdate.Enabled = false;

            using (SqlConnection conn2 = new SqlConnection())
            {
                using (SqlCommand cmd2 = new SqlCommand())
                {
                    conn2.ConnectionString = (string)Session["conDWADMIN2"];

                    // saved comments 
                    if (SavedID == 1)
                    {
                        cmd2.CommandType = CommandType.StoredProcedure;
                        cmd2.Connection = conn2;
                        cmd2.CommandText = "usp_APPS_SPM_Insert_Branch_Queries_Comment";

                        SqlParameter pCommentID = cmd2.Parameters.Add("@CommentID", SqlDbType.Int);
                        pCommentID.Direction = ParameterDirection.Input;
                        pCommentID.Value = Convert.ToInt32(hidCommentID.Value);

                        if (rgInternalAuditFileNotLoaded.Visible == true)
                        { 

                            SqlParameter pCommentType = cmd2.Parameters.Add("@CommentType", SqlDbType.Int);
                            pCommentType.Direction = ParameterDirection.Input;
                            pCommentType.Value = 3;
                        }

                        else
                        {
                            SqlParameter pCommentType = cmd2.Parameters.Add("@CommentType", SqlDbType.Int);
                            pCommentType.Direction = ParameterDirection.Input;
                            pCommentType.Value = Convert.ToInt32(hidCommentType.Value);
                        }

                        SqlParameter pObjectKey = cmd2.Parameters.Add("@ObjectKey", SqlDbType.Int);
                        pObjectKey.Direction = ParameterDirection.Input;
                        pObjectKey.Value = Convert.ToInt32(hidObjectKey.Value);
                         
                        if (txtCommentHistory.Text.Length > 0)
                        {
                            if (txtNewComment.Text.Trim().Length > 0)
                            {
                                comment = DateTime.Now.ToString() + " -- " + sUsername + " - " + txtNewComment.Text.Trim() + " -- " + txtCommentHistory.Text;
                            }
                            else
                            {
                                comment = txtCommentHistory.Text;
                            }

                        }
                        else
                        {
                            if (txtNewComment.Text.Trim().Length > 0)
                            {
                                comment = DateTime.Now.ToString() + " -- " + sUsername + " - " + txtNewComment.Text.Trim() + " -- " + txtCommentHistory.Text;
                            }

                        }

                        SqlParameter pComment = cmd2.Parameters.Add("@CommentText", SqlDbType.VarChar, 2000);
                        pComment.Direction = ParameterDirection.Input;
                        pComment.Value = comment;

                        SqlParameter pUserName = cmd2.Parameters.Add("@UserName", SqlDbType.VarChar, 50);
                        pUserName.Direction = ParameterDirection.Input;
                        pUserName.Value = sUsername;

                        SqlParameter pBranchID = cmd2.Parameters.Add("@BranchID", SqlDbType.VarChar, 4);
                        pBranchID.Direction = ParameterDirection.Input;
                        pBranchID.Value = hidBranchID.Value;

                        SqlParameter pQueryStatus = cmd2.Parameters.Add("@QueryStatus", SqlDbType.Int);
                        pQueryStatus.Direction = ParameterDirection.Input;
                        pQueryStatus.Value = Convert.ToInt32(hidQueryStatus.Value);

                        conn2.Open();
                        cmd2.ExecuteNonQuery();
                        conn2.Close();
                        txtCommentHistory.Text = comment.Replace("--", Environment.NewLine);
                        txtNewComment.Text = "";
                    }
                }

            }
        }
        protected void lntComment_Click(object sender, EventArgs e)
        {
            btnUpdate.Enabled = true;
            txtCommentHistory.Text = "";
            txtNewComment.Text = "";
            lblErrorSavedBox.Visible = false;

            LinkButton bntsubmit = sender as LinkButton;

            string[] commandArge = bntsubmit.CommandArgument.ToString().Split(new char[] { ';' });

            hidCommentID.Value = commandArge[0];
            hidObjectKey.Value = commandArge[1];
            hidCommentType.Value = commandArge[2];
            hidSupplierRef.Value = commandArge[3];
            hidLeadPassenger.Value = commandArge[4];
            hidBranchID.Value = commandArge[5];
            hidQueryStatus.Value = commandArge[6];

            using (SqlConnection conn2 = new SqlConnection())
            {
                using (SqlCommand cmd2 = new SqlCommand())
                {
                    conn2.ConnectionString = (string)Session["conDWADMIN2"];
                    // other varaibles 
                    cmd2.CommandType = CommandType.StoredProcedure;
                    cmd2.Connection = conn2;
                    cmd2.CommandText = "usp_APPS_SPM_Get_Branch_Queries_Comment";
                    conn2.Open();

                    SqlParameter pCommentID = cmd2.Parameters.Add("@CommentID", SqlDbType.Int);
                    pCommentID.Direction = ParameterDirection.Input;
                    pCommentID.Value = Convert.ToInt32(hidCommentID.Value);

                    SqlParameter pObjectKey = cmd2.Parameters.Add("@ObjectKey", SqlDbType.Int);
                    pObjectKey.Direction = ParameterDirection.Input;
                    pObjectKey.Value = Convert.ToInt32(hidObjectKey.Value);

                    using (SqlDataReader data = cmd2.ExecuteReader())
                    {
                        while (data.Read())
                        {
                            // show the comment 
                            txtCommentHistory.Text = data["CommentText"].ToString() + Environment.NewLine;
                        }
                    }

                    //this show date and time stamp order 
                    txtCommentHistory.Text = txtCommentHistory.Text.Replace("--", Environment.NewLine);
                    conn2.Close();
                    popup.Attributes["class"] = "lbpopup";
                    overlay.Attributes["class"] = "lboverlay";
                }
            }
            
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            lblErrorSavedBox.Visible = false;
            try
            {
                if (txtNewComment.Text == "")
                {

                    lblErrorSavedBox.Text = "Please enter a Comment";
                    lblErrorSavedBox.Visible = true;
                }

                else
                {
                    SavedBranchQueries(1);
                    popup.Attributes["class"] = "lbpopuph";
                    overlay.Attributes["class"] = "lboverlayh";

                    if (iGridView == 1)
                    {
                        LoadGrid(selTradingName.Value, selBranchCode.Value, iGridView);
                        ColourGrid(1);
                    }
                    else
                    {
                        LoadGrid("Please Select a Trading Name", "Please Select a Branch", iGridView);
                        ColourGrid(2);
                    }
                    lblSavedSuccessfully.Text = "Saved Successfully for Supplier Ref: " + hidSupplierRef.Value + " and Lead Passenger: " + hidLeadPassenger.Value;
                    lblSavedSuccessfully.Visible = true;

                }
            }
            catch (Exception ex)
            {
                lblErrorSavedBox.Text = ex.Message;
                lblErrorSavedBox.Visible = false;
            }
        }
        
        protected void lnkInternalAuditStatus_Click(object sender, EventArgs e)
        {
            DateLoadedLightbox();
            try
            {
                internalAuditElementRef.Value = "";

                LoadDetail(0, sender);

                //to update the booking data and differences days from a pre loaded element ref 
                if (internalAuditElementRef.Value != "")
                {
                    txtSupplierBookingDateDetail_TextChanged(sender, e);
                }
                popupInternalAuditFileNotLoadedDetails.Attributes["class"] = "lbpopup";
                overlayInternalAuditFileNotLoadedDetails.Attributes["class"] = "lboverlay";

            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }

        }

        private void LoadDetail(int SelectElement ,object sender)
        {
            lblErrorInternalAuditSupplierDetail.Visible = false;
            
            if(lblWarningChangesMade.Visible == false)
            {
                lblWarningChangesMade.Visible = false;
                cbxClose.Checked = false;
                txtCloseDate.Text = "";
                
            }
            else
            {
                lblWarningChangesMade.Visible = true;
               

            }

            txtChangesMade.Text = "";
            if (txtChangesMade.Visible == false)
            {
                txtChangesMade.Visible = false;
         
            }
            else
            {
                txtChangesMade.Visible = true;
            }

            //data bind the drop down list
            ddlFundType.DataSource = sslDDLFundType;
            ddlFundType.DataValueField = "Lookupkey";
            ddlFundType.DataTextField = "Lookupvalue";
            ddlFundType.DataBind();

            ddlBookingMethod.DataSource = sslDDLBookingMethod;
            ddlBookingMethod.DataValueField = "Lookupkey";
            ddlBookingMethod.DataTextField = "Lookupvalue";
            ddlBookingMethod.DataBind();

            ddlInternalAuditStatus.DataSource = sslDDLInternalAuditStatus;
            ddlInternalAuditStatus.DataValueField = "Lookupkey";
            ddlInternalAuditStatus.DataTextField = "Lookupvalue";
            ddlInternalAuditStatus.DataBind();

            txtSupplierPaymentComment.Text = "";

            using (SqlConnection conn2 = new SqlConnection())
            {
                using (SqlCommand cmd2 = new SqlCommand())
                {
                    conn2.ConnectionString = (string)Session["conDWADMIN2"];
                    cmd2.CommandType = CommandType.StoredProcedure;
                    cmd2.Connection = conn2;

                    if (SelectElement == 0)
                    {
                        LinkButton lnkInternalAuditStatus = sender as LinkButton;

                        string[] commandagr = lnkInternalAuditStatus.CommandArgument.ToString().Split(new char[] { ';' });

                        hidFileNotLoadedID.Value = commandagr[0];
                        hidQueryID.Value = commandagr[1];
                        hidSupplierRefInternalAuditSupplierDetails.Value = commandagr[2];
                        hidLeadPassengerInternalAuditSupplierDetails.Value = commandagr[3];
                        hidComment.Value = commandagr[4];
                        hidCommentIDModal.Value = commandagr[5];

                        cmd2.CommandText = "usp_APPS_SPM_Supplier_Payment_Audit_Details";
                        conn2.Open();

                        SqlParameter pFileNotLoadedID = cmd2.Parameters.Add("@FileNotLoaded", SqlDbType.Int);
                        pFileNotLoadedID.Direction = ParameterDirection.Input;
                        pFileNotLoadedID.Value = Convert.ToInt32(hidFileNotLoadedID.Value);

                        SqlParameter pQueryID = cmd2.Parameters.Add("@StatementLineID", SqlDbType.Int);
                        pQueryID.Direction = ParameterDirection.Input;
                        pQueryID.Value = Convert.ToInt32(hidQueryID.Value);

                        using (SqlDataReader data = cmd2.ExecuteReader())
                        {
                            while (data.Read())
                            {
                                txtSupplierBookingDateDetail.Text =data["SupplierBookingDate"].ToString();
                                txtDateFunded.Text = data["DateFunded"].ToString();
                                ddlFundType.SelectedValue = data["FundType"].ToString();
                                ddlBookingMethod.SelectedValue = data["BookingMethod"].ToString();
                                ddlInternalAuditStatus.SelectedValue = data["InternalAuditStatus"].ToString();
                                txtSupplierPaymentComment.Text = data["SPAMComment"].ToString();
                                internalAuditElementRef.Value = data["ElementRef"].ToString();
                            }
                        }
                        conn2.Close();

                        if(txtSupplierBookingDateDetail.Text == "01/01/1900")
                        {
                            txtSupplierBookingDateDetail.Text = "";
                        }
                        
                        DateLoadedLightbox();
                        
                        if (txtSupplierBookingDateDetail.Text == "")
                        {
                            lblDifferenceDays.Text = "0";
                        }
                        else
                        {
                            CalulateDaysDifferent();
                        }

                    }
                    //refresh the light box  with the new element details
                    else
                    {
                        cmd2.CommandText = "usp_APPS_SPM_Supplier_Payment_Audit_Details_Elements";
                        conn2.Open();

                        SqlParameter pElementRef = cmd2.Parameters.Add("@ElementRef", SqlDbType.VarChar, 50);
                        pElementRef.Direction = ParameterDirection.Input;
                        pElementRef.Value = internalAuditElementRef.Value;

                        using (SqlDataReader data = cmd2.ExecuteReader())
                        {
                            while (data.Read())
                            {
                                DateLoaded = Convert.ToDateTime(data["BookingDate"]);
                            }
                        }

                        conn2.Close();
                        lblDateLoaded.Text = DateLoaded.ToString("dd/MM/yyyy");

                        CalulateDaysDifferent();

                        //refresh the grid to stop post back delete informantion from the controls 
                        cmd2.Parameters.Clear();
                        cmd2.CommandText = "usp_APPS_SPM_Supplier_Payment_Audit_Details";
                        conn2.Open();


                        SqlParameter pFileNotLoadedID = cmd2.Parameters.Add("@FileNotLoaded", SqlDbType.Int);
                        pFileNotLoadedID.Direction = ParameterDirection.Input;
                        pFileNotLoadedID.Value = Convert.ToInt32(hidFileNotLoadedID.Value);

                        SqlParameter pQueryID = cmd2.Parameters.Add("@StatementLineID", SqlDbType.Int);
                        pQueryID.Direction = ParameterDirection.Input;
                        pQueryID.Value = Convert.ToInt32(hidQueryID.Value);

                        using (SqlDataReader data = cmd2.ExecuteReader())
                        {
                            while (data.Read())
                            {
                                // update this part to stop post back removed data from the drop down list
                                if (!Page.IsPostBack)
                                {
                                    txtDateFunded.Text = data["DateFunded"].ToString();
                                    ddlFundType.SelectedValue = data["FundType"].ToString();
                                    ddlBookingMethod.SelectedValue = data["BookingMethod"].ToString();
                                    ddlInternalAuditStatus.SelectedValue = data["InternalAuditStatus"].ToString();
                                    txtSupplierPaymentComment.Text = data["SPAMComment"].ToString();
                                }
                            }
                        }
                        conn2.Close();

                        if (txtSupplierBookingDateDetail.Text == "01/01/1900")
                        {
                            txtSupplierBookingDateDetail.Text = "";
                        }
                    }
                }
            }
        }

        private void DateLoadedLightbox()
        {
            using (SqlConnection conn2 = new SqlConnection())
            {
                using (SqlCommand cmd2 = new SqlCommand())
                {
                    conn2.ConnectionString = (string)Session["conDWADMIN2"];
                    cmd2.CommandType = CommandType.StoredProcedure;
                    cmd2.Connection = conn2;

                    cmd2.CommandText = "usp_APPS_SPM_Supplier_Payment_Audit_Details_Elements";
                    conn2.Open();

                    SqlParameter pElementRef = cmd2.Parameters.Add("@ElementRef", SqlDbType.VarChar, 50);
                    pElementRef.Direction = ParameterDirection.Input;
                    pElementRef.Value = internalAuditElementRef.Value;


                    using (SqlDataReader data = cmd2.ExecuteReader())
                    {
                        while (data.Read())
                        {
                            DateLoaded = Convert.ToDateTime(data["BookingDate"]);
                        }
                    }

                    conn2.Close();
                    lblDateLoaded.Text = DateLoaded.ToString("dd/MM/yyyy");
                }
            }
        }

        protected void txtSupplierBookingDateDetail_TextChanged(object sender, EventArgs e)
        {
            try
            {
                lblErrorInternalAuditSupplierDetail.Visible = false;

                SelectedIndexChanged(sender, e);

            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
        }

        private void CalulateDaysDifferent()
        {
            TimeSpan DifferenceDays;
            if(!string.IsNullOrEmpty(txtSupplierBookingDateDetail.Text))
            {
                DifferenceDays = Convert.ToDateTime(txtSupplierBookingDateDetail.Text) - DateLoaded;

                lblDifferenceDays.Text = (Math.Round(Convert.ToDouble(DifferenceDays.TotalDays), 0).ToString());
            }
            
        }

        protected void cbxClose_CheckedChanged(object sender, EventArgs e)
        {            
            if (cbxClose.Checked)
            {
                txtCloseDate.Text = DateTime.Today.Date.ToShortDateString();
            }
            else
            {
                txtCloseDate.Text = "";
            }
        }       

        // checking the is vaild element ref 
        protected bool isvaildExtension(string extension)
        {
            switch (extension.ToLower())
            {
                case "hay":
                case "bus":
                case "htr":
                case "htf":
                case "hbd":
                case "min":
                case "btm":
                case "hpl":
                    return true;

                default:
                    return false;
            }
        }
        // report credentails 
        public class CustomReportCredentials : IReportServerCredentials
        {
            private string _UserName;
            private string _PassWord;
            private string _DomainName;

            public CustomReportCredentials(string UserName, string PassWord, string DomainName)
            {
                _UserName = UserName;
                _PassWord = PassWord;
                _DomainName = DomainName;
            }

            public System.Security.Principal.WindowsIdentity ImpersonationUser
            {
                get { return null; }
            }

            public ICredentials NetworkCredentials
            {
                get { return new NetworkCredential(_UserName, _PassWord, _DomainName); }
            }

            public bool GetFormsCredentials(out Cookie authCookie, out string user,
             out string password, out string authority)
            {
                authCookie = null;
                user = password = authority = null;
                return false;
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if (isvaildExtension(internalAuditElementRef.Value.Substring(0, 3)) == false)
            {
                lblErrorInternalAuditSupplierDetail.Text = "Element Ref must contain the folowing reference HAY-/HTR-/HTF-/HBD-/BUS-/MIN-/BTM-/HPL-. ";
                lblErrorInternalAuditSupplierDetail.Visible = true;
            }
            else if (internalAuditElementRef.Value.Contains("/") == false)
            {
                lblErrorInternalAuditSupplierDetail.Text = "Element Ref does not contain a / at the end";
                lblErrorInternalAuditSupplierDetail.Visible = true;
               
            }
            else if (internalAuditElementRef.Value.Contains("-") == false)
            {
                lblErrorInternalAuditSupplierDetail.Text = "Element Ref does not contain a -";
                lblErrorInternalAuditSupplierDetail.Visible = true;
           
            }
            else if (int.TryParse(internalAuditElementRef.Value.Substring(4, internalAuditElementRef.Value.IndexOf('/') - internalAuditElementRef.Value.IndexOf('-') - 1), out n) == false)
            {
                lblErrorInternalAuditSupplierDetail.Text = "Element Ref is not a vaild Reference";
                lblErrorInternalAuditSupplierDetail.Visible = true;
              
            }
            else
            {
                try
                {
                    lblErrorInternalAuditSupplierDetail.Visible = false;

                    LoadDetail(1, sender);

                }
                catch (Exception ex)
                {
                    lblError.Text = ex.Message;
                    lblError.Visible = true;
                }
            }

        }

        //on startup
        protected void SetHiddenFields()
        {
            // hiddden field names need to be the same as the matching control e.g. ddlShutup becomes hdnShutup
            hdnSupplierBookingDateDetail.Value = txtSupplierBookingDateDetail.Text;
            hdnDateFunded.Value = txtDateFunded.Text;
            hdnFundType.Value = ddlFundType.SelectedValue;
            hdnBookingMethod.Value = ddlBookingMethod.SelectedValue;
            hdnInternalAuditStatus.Value = ddlInternalAuditStatus.SelectedValue;
            hdnSupplierPaymentComment.Value = txtSupplierPaymentComment.Text;
            hdnClose.Value = cbxClose.Checked.ToString();
            
        }

        protected void SelectedIndexChanged(object sender, EventArgs e)
        {
            string controlID = String.Empty;
            string ctype = sender.GetType().ToString();
            switch (ctype)
            {
                case "System.Web.UI.WebControls.DropDownList":
                    controlID = (((DropDownList)sender).ID).TrimStart("ddl".ToCharArray());
                    ValidateControlSelectedValues(controlID, (DropDownList)sender, "ddl");
                    break;
                case "System.Web.UI.WebControls.TextBox":
                    controlID = (((TextBox)sender).ID).TrimStart("txt".ToCharArray());
                    ValidateControlSelectedValues(controlID, (TextBox)sender, "txt");
                    break;
                case "System.Web.UI.WebControls.CheckBox":
                    controlID = (((CheckBox)sender).ID).TrimStart("cbx".ToCharArray());
                    ValidateControlSelectedValues(controlID, (CheckBox)sender, "cbx");
                    break;
                default:
                    break;
            }
        }

        private void ValidateControlSelectedValues(string controlID, Control control, string typePrefix)
        {
            ContentPlaceHolder cph = (ContentPlaceHolder)Page.Master.FindControl("ContentPlaceHolder1");

            if (typePrefix == "ddl")
            {
                string ddlValue = ((DropDownList)control).SelectedValue;
                string hdnValue = ((HiddenField)cph.FindControl("hdn" + controlID)).Value;

                if (ddlValue != hdnValue)
                {
                    // show warning message 
                    lblWarningChangesMade.Text = "Please enter a comment";
                    lblWarningChangesMade.Visible = true;
                    txtChangesMade.Visible = true;

                }
            }
            if (typePrefix == "txt")
            {
                string txtValue = ((TextBox)control).Text;
                string hdnValue = ((HiddenField)cph.FindControl("hdn" + controlID)).Value;

                if (txtValue != hdnValue)
                {
                    // show warning message
                    lblWarningChangesMade.Text = "Please enter a comment";
                    lblWarningChangesMade.Visible = true;
                    txtChangesMade.Visible = true;

                }
            }
            if (typePrefix == "cbx")
            {
                bool cbxValue = ((CheckBox)control).Checked;
                HiddenField cbx = (HiddenField)cph.FindControl("hdn" + controlID);
                bool hdnValue = bool.Parse(((HiddenField)cph.FindControl("hdn" + controlID)).Value);

                if (cbxValue != hdnValue)
                {
                    // show warning message
                    lblWarningChangesMade.Text = "Please enter a comment";
                    lblWarningChangesMade.Visible = true;
                    txtChangesMade.Visible = true;

                }
            }
        }
        private void ScrollToStatementLine()
        {            
            string sHash = "location.hash = 'sl" + hidFileNotLoadedID.Value + "';";
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "hash", sHash, true);           
        }
       
        protected void rgManagerViewFileNotLoaded_ItemDataBound(object sender, GridItemEventArgs e)
        {
            if (e.Item.ItemType == GridItemType.Item)
            {
                ((DropDownList)e.Item.FindControl("ddlAction")).SelectedValue = DataBinder.Eval(e.Item.DataItem, "Action").ToString();
            }
            ColourGrid(1);
        }
               
        protected void rgManagerViewFileNotLoaded_PageIndexChanged(object sender, GridPageChangedEventArgs e)
        {
            rgManagerViewFileNotLoaded.DataBind();
        }

        protected void rtInternalAuditReport_ButtonClick(object sender, RadToolBarEventArgs e)
        {
            RadToolBarButton btn = e.Item as RadToolBarButton;

            if (btn.CommandName == "ExportToExcel")
            {
                rgFileNotLoadedReport.ExportSettings.FileName = "ExportedFile";
                rgFileNotLoadedReport.MasterTableView.GetColumn("CommentText2").Display = true;
                rgFileNotLoadedReport.ExportSettings.Excel.Format = (GridExcelExportFormat)Enum.Parse(typeof(GridExcelExportFormat), "Xlsx");
                rgFileNotLoadedReport.ExportSettings.IgnorePaging = true;
                rgFileNotLoadedReport.ExportSettings.ExportOnlyData = true;
                rgFileNotLoadedReport.ExportSettings.OpenInNewWindow = true;
                rgFileNotLoadedReport.MasterTableView.ExportToExcel();
            }
        }

        protected void rgManagerViewFileNotLoaded_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
        {
            rgManagerViewFileNotLoaded.Rebind();
        }

        protected void rgInternalAuditFileNotLoaded_ItemDataBound(object sender, GridItemEventArgs e)
        {
            ColourGrid(2);
        }
    }
} 