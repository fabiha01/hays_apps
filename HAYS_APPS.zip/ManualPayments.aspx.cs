﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text.RegularExpressions;
using System.Threading;
using System.IO;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using GenericParsing;
using Telerik.Web.UI;

namespace Apps.SPAM
{
    public partial class ManualPayments : System.Web.UI.Page
    {
        DateTime testdate;
        int n;
        decimal d;
        string path;
        Decimal netttotal = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                ClearAll();
            }

            chkSelectBank.InputAttributes.Add("data-toggle", "toggle");
            chkSelectBank.InputAttributes.Add("data-off", "No");
            chkSelectBank.InputAttributes.Add("data-on", "Yes");
            chkSelectBank.InputAttributes.Add("data-onstyle", "danger");
            chkSelectBank.InputAttributes.Add("onchange", "this.onclick();");
        }
        private void ClearAll()
        {
            DataTable dt = new DataTable();
            dt.Columns.AddRange(new DataColumn[2] { new DataColumn("ElementRef", typeof(string)),
                                                    new DataColumn("AmountPaid",typeof(decimal)) });

            dt.Rows.Add(dt.NewRow());
            rgManualPayment.DataSource = dt;
            rgManualPayment.DataBind();

            txtPayment.Text = "";
            ddlCompany.SelectedIndex = 0;
            ddlPaymentMethod.SelectedIndex = 0;


        }
        protected void btnPaste_Click(object sender, EventArgs e)
        {
            try
            {
                if(FileUpload.FileName == "")
                {
                    Upload(1);
                }
                else
                {
                    Upload(2);
                }

            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;//"Can't imported the file. Please try it again";
                lblError.Visible = true;
            }

        }
 
        private void Upload(int UploadType)
        {

            DataTable dt = new DataTable();
            dt.Columns.AddRange(new DataColumn[2] { new DataColumn("ElementRef", typeof(string)),
                                                    new DataColumn("AmountPaid",typeof(decimal)) });
            lblError.Visible = false;

            // from the clipboard
            if (UploadType == 1)
            {
                var tsmtp = hidCopyfromtheClipboard.Value;
                string copiedContent = tsmtp;

                foreach (string row in copiedContent.Split('\n'))
                {
                    if (!string.IsNullOrEmpty(row))
                    {
                        dt.Rows.Add();
                    

                        int i = 0;
                        foreach (string cell in row.Split('\t'))
                        {
                            string cellVal = cell;

                            // find number value by find the end of the string and testing value as a decimal
                            if (cellVal.EndsWith("\r") == true)
                            {
                                // test if it a descimal or not 
                                if (decimal.TryParse(cellVal, out d) == false)
                                {
                                    lblError.Text = "Incorrect Payment Amount - Check the file";
                                    lblError.Visible = true;
                                    break;
                                }
                                else
                                {
                                    dt.Rows[dt.Rows.Count - 1][i] = cellVal;
                                }

                            }
                            else
                            {
                                dt.Rows[dt.Rows.Count - 1][i] = cellVal.Trim();
                            }

                            i++;
                        }

                    }
                }
            }
            // from CSV file
            else
            {
                try
                {

                    GenericParser parser = new GenericParser();
                    TextReader tr = new StreamReader(FileUpload.FileContent);

                    parser.SetDataSource(tr);
                    parser.ColumnDelimiter = ',';
                    parser.FirstRowHasHeader = true;
                    parser.MaxBufferSize = 4096;
                    parser.TextQualifier = '\"';

                    while (parser.Read())
                    {
                        if (!parser.IsCurrentRowEmpty && !String.IsNullOrEmpty(parser[0].ToString()) && !String.IsNullOrEmpty(parser[1].ToString()))
                        {
                            dt.Rows.Add();
                            dt.Rows[dt.Rows.Count - 1][0] = parser[0].Trim();
                            dt.Rows[dt.Rows.Count - 1][1] = parser[1].Trim();
                        }
                    }

                  
                }
                catch (Exception ex)
                {
                    lblError.Text = ex.Message;//"Can't imported the file. Please try it again";
                    lblError.Visible = true;
                }

            }

            if(lblError.Visible == false)
            {
                // bind to data grid
                rgManualPayment.DataSource = dt;
                rgManualPayment.DataBind();
            }
            AmountDue();
        }

        protected void btnPay_Click(object sender, EventArgs e)
        {
            lblError.Visible = false;

            try
            {
                if (DateTime.TryParse(txtPayment.Text, out testdate) == false)
                {
                    lblError.Text = "Invalid Date";
                    lblError.Visible = true;
                }
                else if(ddlPaymentMethod.SelectedValue == "0")
                {
                    lblError.Text = "Select a Payment Method";
                    lblError.Visible = true;
                }
                else
                {
                    Pay(Convert.ToInt32(ddlCompany.SelectedValue), Convert.ToDateTime(txtPayment.Text), Convert.ToInt32(ddlPaymentMethod.SelectedValue));
                 
                }
            }
            catch(Exception ex )
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }

        }
        private void Pay(int CompanyID, DateTime PaymentDate, int PaymentMethod)
        {
            MatchStatement service = new MatchStatement();

            // insert into manaul payment 
            using (SqlConnection conn = new SqlConnection())
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Parameters.Clear();

                    conn.ConnectionString = (string)Session["conDWADMIN2"];
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = conn;

                    cmd.CommandText = "usp_APPS_SPM_Insert_Manual_Payment";

                    conn.Open();

                    SqlParameter pCompanyID = cmd.Parameters.Add("@CompanyID", SqlDbType.Int);
                    pCompanyID.Direction = ParameterDirection.Input;
                    pCompanyID.Value = CompanyID;

                    SqlParameter pPaymentDate = cmd.Parameters.Add("@PaymentDate", SqlDbType.Date);
                    pPaymentDate.Direction = ParameterDirection.Input;
                    pPaymentDate.Value = PaymentDate;

                    SqlParameter pPaymentMethod = cmd.Parameters.Add("@PaymentMethod", SqlDbType.Int);
                    pPaymentMethod.Direction = ParameterDirection.Input;
                    pPaymentMethod.Value = PaymentMethod;

                    SqlParameter pManualPaymentID = cmd.Parameters.Add("@ManualPaymentID", SqlDbType.Int);
                    pManualPaymentID.Direction = ParameterDirection.Output;

                    // If they have overridden the bank account, pass this in. Otherwise it will default on SQL side to NULL
                    // and use normal behaviour of correct bank account for each element's currency and company
                    if (chkSelectBank.Checked)
                    {
                        cmd.Parameters.AddWithValue("@OverrideBankAccount", ddlBankAccount.SelectedValue);
                    }

                    cmd.ExecuteNonQuery();

                    //return manual pyament id to hidden value manual payment field
                    hidManualPaymentID.Value = cmd.Parameters["@ManualPaymentID"].Value.ToString();

                    //insert into manual payment details
                    cmd.CommandText = "usp_APPS_SPM_Insert_Manual_Payment_Details";

                    foreach (GridItem row in rgManualPayment.Items)
                    {
                        cmd.Parameters.Clear();

                        Label lblElementref = row.FindControl("lblElementRef") as Label;
                        Label lblAmountPaid = row.FindControl("lblAmountPaid") as Label;


                        if (lblElementref.Text == "")
                        {
                            lblError.Text = "Element Ref can't be blank";
                            lblError.Visible = true;
                            break;
                        }
                        else if (isvaildExtension(lblElementref.Text.Substring(0, 3)) == false)
                        {
                            lblError.Text = "Element Ref must contain the folowing reference HAY-/HTR-/HTF-/HBD-/BUS-/MIN-/BTM-/HPL-. ";
                            lblError.Visible = true;
                            break;

                        }
                        else if (lblElementref.Text.Contains("/") == false)
                        {
                            lblError.Text = "Element Ref does not contain a / at the end";
                            lblError.Visible = true;
                            break;
                        }
                        else if (lblElementref.Text.Contains("-") == false)
                        {
                            lblError.Text = "Element Ref does not contain a -";
                            lblError.Visible = true;
                            break;
                        }
                        else if (int.TryParse(lblElementref.Text.Substring(4, lblElementref.Text.IndexOf('/') - lblElementref.Text.IndexOf('-') - 1), out n) == false)
                        {
                            lblError.Text = "Element Ref is not a vaild Reference";
                            lblError.Visible = true;
                            break;
                        }
                        else if (decimal.TryParse(lblAmountPaid.Text, out d) == false)
                        {
                            lblError.Text = "Amount paid is not a vaild";
                            lblError.Visible = true;
                            break;
                        }
                        else
                        {
                            SqlParameter pManualPaymentIDs = cmd.Parameters.Add("@ManualPaymentID", SqlDbType.Int);
                            pManualPaymentIDs.Direction = ParameterDirection.Input;
                            pManualPaymentIDs.Value = Convert.ToInt32(hidManualPaymentID.Value);

                            SqlParameter pElementRef = cmd.Parameters.Add("@ElementRef", SqlDbType.VarChar, 50);
                            pElementRef.Direction = ParameterDirection.Input;
                            pElementRef.Value = lblElementref.Text;

                            SqlParameter pPaymentAmount = cmd.Parameters.Add("@PaymentAmount", SqlDbType.Decimal);
                            pPaymentAmount.Precision = 14;
                            pPaymentAmount.Scale = 2;
                            pPaymentAmount.Direction = ParameterDirection.Input;
                            pPaymentAmount.Value = Convert.ToDecimal(lblAmountPaid.Text);

                            cmd.ExecuteNonQuery();
                        }
                    }
                   
                }
            }

            if(lblError.Visible == false)
            {
                ///Calling Paying Serivce
                service.PayManualPayment(Convert.ToInt32(hidManualPaymentID.Value), Request.ServerVariables["LOGON_USER"]);

                //diplay model box 
                lblModelDialogTitle.Text = "Statement Submitted";
                lblModalDialogBody.Text = string.Format(@"You have successfully submitted Manual Payment ""{0}""<br \>
                                                            This Manual Payment is now being processed by NAV, you should receive a notification when this is complete."
                                                    , hidManualPaymentID.Value);

                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModalDialog", "$('#myModalDialog').modal();", true);

                lblPaymentSuccessfully.Visible = true;

                ClearAll();
            }

        }
        
        protected void AmountDue()
        {
            GridFooterItem footerItem = (GridFooterItem)rgManualPayment.MasterTableView.GetItems(GridItemType.Footer)[0];

            foreach (GridItem row in rgManualPayment.Items)
            {
                Label lblAmountPaid = (Label)row.FindControl("lblAmountPaid");
                
                netttotal += Convert.ToDecimal(lblAmountPaid.Text);
            }

            Label lblTotal = (Label)footerItem.FindControl("lblTotal");

            lblTotal.Text = netttotal.ToString("N2");
           
           
        }

        //test element ref start 
        protected bool isvaildExtension(string extension)
        {
            switch (extension.ToLower())
            {
                case "hay":
                case "bus":
                case "htr":
                case "htf":
                case "hbd":
                case "min":
                case "btm":
                case "hpl":
                    return true;

                default:
                    return false;
            }
        }

        protected void chkSelectBank_CheckedChanged(object sender, EventArgs e)
        {
            lblBankWarning.Visible = chkSelectBank.Checked;
            ddlBankAccount.Visible = chkSelectBank.Checked;
            lblBankAccount.Visible = chkSelectBank.Checked;
        }
        
    }
}