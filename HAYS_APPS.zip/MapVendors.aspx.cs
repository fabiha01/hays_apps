﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data;


namespace Apps.SPAM
{
    public partial class MapVendors : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                using (HaysTravelLtd_MSCRMEntities crm = new HaysTravelLtd_MSCRMEntities())
                {
                    var vdrs = crm.joy_cvmtradingname.Where(x => x.statecode == 0).Select(x => new { x.joy_name, x.joy_cvmtradingnameId });
                    selVendorsExisting.DataSource = vdrs.ToList();
                    selVendorsExisting.DataValueField = "joy_cvmtradingnameId";
                    selVendorsExisting.DataTextField = "joy_name";
                    selVendorsExisting.DataBind();
                }
            }

            bindGrid();

            //hide label
            lblError.Visible = false;
            lblSuccess.Visible = false;
        
        }

        protected void bindGrid()
        {
            sslDDLMapVendors.SelectParameters[0].DefaultValue = selVendorsExisting.Value;
            rgGridMappings.DataSource = sslDDLMapVendors;
            rgGridMappings.DataBind();
            
        }

        protected void btnMap_Click(object sender, EventArgs e)
        {
            
            try
            {
                using (SpamEntities spam = new SpamEntities())
                {
                    NAV_Vendor v = spam.NAV_Vendor.Where(x => x.No_ == txtMapTarget.Text).FirstOrDefault();

                    if (v != null)
                    {
                        using (SqlConnection conn = new SqlConnection())
                        {
                            using (SqlCommand cmd = new SqlCommand())
                            {
                                conn.ConnectionString = (string)Session["conDWADMIN2"];
                                // other varaibles 
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Connection = conn;
                                cmd.CommandText = "usp_APPS_SPM_Insert_Delete_Vendor_Mapping";
                                conn.Open();

                                SqlParameter pStatmentID = cmd.Parameters.Add("@StatementID", SqlDbType.UniqueIdentifier);
                                pStatmentID.Direction = ParameterDirection.Input;
                                pStatmentID.Value = Guid.Parse(selVendorsExisting.Value);

                                SqlParameter pStamentName = cmd.Parameters.Add("@StatementName", SqlDbType.VarChar, 500);
                                pStamentName.Direction = ParameterDirection.Input;
                                pStamentName.Value = selVendorsExisting.Items[selVendorsExisting.SelectedIndex].Text;

                                SqlParameter pChildVendor = cmd.Parameters.Add("@ChildVendor", SqlDbType.VarChar, 20);
                                pChildVendor.Direction = ParameterDirection.Input;
                                pChildVendor.Value = txtMapTarget.Text;

                                SqlParameter pDateMapped = cmd.Parameters.Add("@DateMapped", SqlDbType.DateTime);
                                pDateMapped.Direction = ParameterDirection.Input;
                                pDateMapped.Value = DateTime.Now;

                                SqlParameter pMappedBy = cmd.Parameters.Add("@Mappedby", SqlDbType.VarChar, 200);
                                pMappedBy.Direction = ParameterDirection.Input;
                                pMappedBy.Value = Session["Username"].ToString();

                                SqlParameter pCompanyID = cmd.Parameters.Add("@CompanyID", SqlDbType.Int);
                                pCompanyID.Direction = ParameterDirection.Input;
                                pCompanyID.Value = Convert.ToInt32(ddlCompany.SelectedValue);

                                SqlParameter pInsertORDelete = cmd.Parameters.Add("@InsertORDelete", SqlDbType.Int);
                                pInsertORDelete.Direction = ParameterDirection.Input;
                                pInsertORDelete.Value = 1;

                                cmd.ExecuteNonQuery();

                                //            SPM_Vendor_Mapping (SevMap = new SPM_Vendor_Mapping();

                                //            vMap.StatementId = Guid.Parse(selVendorsExisting.Value);
                                //            vMap.StatementName = selVendorsExisting.Items[selVendorsExisting.SelectedIndex].Text;
                                //            vMap.Child_Vendor = txtMapTarget.Text;
                                //            vMap.Date_Mapped = DateTime.Now;
                                //            vMap.Mapped_By = Session["Username"].ToString();
                                txtMapTarget.Text = "";
                                lblError.Visible = false;
                                lblSuccess.Text = "Vendor Mapped Successfully";
                                lblSuccess.Visible = true;

                                bindGrid();
                            }
                        }
                    }

                    else
                    {
                        lblError.Text = "That Vendor Code does not exist in NAV, please check the data you have input";
                        lblError.Visible = true;
                        lblSuccess.Visible = false;
                    }
                }

            }
            catch(Exception ex)
            {
                Console.Write(ex.Message);
            }
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
           
            LinkButton lnkDelete = sender as LinkButton;

            string[] commandAgr = lnkDelete.CommandArgument.ToString().Split(new char[] { ';' });

   
            hidChildVendor.Value = commandAgr[1].ToString();
            hidStatementID.Value = commandAgr[0].ToString();

            lblDeleteVenderCode.Text = " Would you like to delete this Vender code " + hidChildVendor.Value + " from the database?";

            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "ModalDeleteVenderCode", "$('#ModalDeleteVenderCode').modal('show');", true);
       
        }

        protected void btnYes_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    conn.ConnectionString = (string)Session["conDWADMIN2"];
                    // other varaibles 
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = conn;
                    cmd.CommandText = "usp_APPS_SPM_Insert_Delete_Vendor_Mapping";
                    conn.Open();

                    SqlParameter pStatmentID = cmd.Parameters.Add("@StatementID", SqlDbType.UniqueIdentifier);
                    pStatmentID.Direction = ParameterDirection.Input;
                    pStatmentID.Value = Guid.Parse(hidStatementID.Value);

                    SqlParameter pChildVendor = cmd.Parameters.Add("@ChildVendor", SqlDbType.VarChar, 20);
                    pChildVendor.Direction = ParameterDirection.Input;
                    pChildVendor.Value = hidChildVendor.Value;

                    SqlParameter pInsertORDelete = cmd.Parameters.Add("@InsertORDelete", SqlDbType.Int);
                    pInsertORDelete.Direction = ParameterDirection.Input;
                    pInsertORDelete.Value = 2;

                    cmd.ExecuteNonQuery();
                }
            }

            lblSuccess.Text = "Vendor Mapping Removed";
            lblSuccess.Visible = true;

            bindGrid();
        }

        protected void btnNO_Click(object sender, EventArgs e)
        {

            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "ModalDeleteVenderCode", "$('#ModalDeleteVenderCode').modal('hide');", true);
        }
    }
}