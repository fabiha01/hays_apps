﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.ServiceModel.Description;
using System.Web;
using System.Web.Services;
using System.IO;
using System.Text;
using static Apps.AppsHelper;

namespace Apps.SPAM
{
    /// <summary>
    /// Summary description for MatchStatement
    /// </summary>
    [WebService(Namespace = "http://haystravel.co.uk/webservices")]
    //[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    //[System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]


    public class MatchStatement : System.Web.Services.WebService
    {
        private delegate void DelegateAction(int param, string user, bool firstRun);
        private delegate void DelegateActionPay(int param, string user);

        [WebMethod]
        public void SaveAndMatch(int param, string user, bool firstRun)
        {
            DelegateAction matcher = new DelegateAction(RunMatchProc);
            matcher.BeginInvoke(param, user, firstRun, null, null);
        }

        private void RunMatchProc(int param, string user, bool firstRun)
        {
            try
            {
                using (OleDbConnection conn = new OleDbConnection(System.Configuration.ConfigurationManager.ConnectionStrings["cstrDW1-DWADMIN"].ConnectionString))
                {
                    conn.Open();
                    using (OleDbCommand cmd = conn.CreateCommand())
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.CommandText = "[dbo].[usp_APPS_SPM_Auto_Matching]";
                        cmd.CommandTimeout = 900;

                        cmd.Parameters.AddWithValue("@StatementID", param);

                        cmd.ExecuteNonQuery();

                        if (firstRun)
                        {
                            using (OleDbCommand cmd2 = conn.CreateCommand())
                            {
                                cmd2.CommandType = CommandType.StoredProcedure;
                                cmd2.CommandText = "usp_APPS_SPM_Carry_Forward_Queries";
                                cmd2.Parameters.AddWithValue("@StatementID", param);
                                cmd2.ExecuteNonQuery();
                            }
                        }

                        int rows = 0;

                        using (SpamEntities spam = new SpamEntities())
                        {
                            rows = spam.SPM_Statement_Lines.Where(x => x.StatementID == param).Count();

                            var statement = spam.SPM_Statement.Where(x => x.StatementID == param).FirstOrDefault();

                            //UpdateCRM((Guid)statement.CompletionList, (Guid)statement.CrmStatementGuid, statement.InitialMatch, statement.NettAmount);
                        }

                        string notiMessage = string.Format("SPAM has matched {0} rows for Statement {1}, Please go to Match Process to see the results.", rows, param);
                        using (NotificationsEntities ne = new NotificationsEntities())
                        {
                            Notification n = new Notification();
                            Notification nr = new Notification();
                            n.System = "SPM";
                            nr.System = "SPM";
                            if (System.Environment.MachineName.ToString() == "Misssql")
                            {
                                n.Url = string.Format("http://apps/SPAM/statementProcess.aspx?StatementID={0}", param);
                                nr.Url = string.Format("http://apps/SPAM/RefundNotOnTheStatement.aspx?StatementID={0}", param);
                            }
                            else
                            {
                                n.Url = string.Format("http://DWTEST/SPAM/StatementProcess.aspx?StatementID={0}", param);
                                nr.Url = string.Format("http://DWTEST/SPAM/RefundNotOnTheStatement.aspx?StatementID={0}", param);
                            }

                            n.Message = notiMessage;
                            nr.Message = string.Format("Refunds Report Ready For Statement {0}", param);
                            n.Recipient = user;
                            nr.Recipient = user;
                            n.Viewed = false;
                            nr.Viewed = false;
                            n.Clicked = false;
                            nr.Clicked = false;
                            n.DateCreated = DateTime.Now;
                            nr.DateCreated = DateTime.Now;

                            ne.Notifications.Add(n);
                            ne.Notifications.Add(nr);
                            ne.SaveChanges();
                        }
                    }
                }
            }
            catch (Exception e)
            {
                using (NotificationsEntities errne = new NotificationsEntities())
                {
                    Notification nerr = new Notification();
                    string emessage = string.Format("Matching error: [{0}] - {1}", param.ToString(), e.Message);
                    emessage = emessage.Length > 1000 ? emessage.Substring(0, 1000) : emessage;
                    nerr.System = "SPM";
                    nerr.Message = emessage;
                    nerr.Recipient = user;
                    nerr.Viewed = false;
                    nerr.Clicked = false;
                    nerr.DateCreated = DateTime.Now;

                    errne.Notifications.Add(nerr);
                    errne.SaveChanges();
                }
            }
            
        }
        //get the statement name
        private string GetStatementName(Guid param)
        {            
            try
            {
                 using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["cstrDW1-DWADMIN2"].ConnectionString))               
                {
                    conn.Open();
                    using (SqlCommand cmd = conn.CreateCommand())
                    {                     

                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.CommandText = "[dbo].[usp_APPS_SPM_Get_StatementName]";
                        cmd.CommandTimeout = 900;

                        cmd.Parameters.AddWithValue("@CRMGuid", param);

                        //SqlParameter returnParameter = cmd.Parameters.Add("StatementName", SqlDbType.VarChar);                       
                        // returnParameter.Direction = ParameterDirection.ReturnValue;

                        //cmd.ExecuteNonQuery();
                        //string result = returnParameter.Value.ToString();

                        string result = cmd.ExecuteScalar().ToString();
                        return result;
                    }
                }
            }
            catch (Exception e)
            {
                using (NotificationsEntities errne = new NotificationsEntities())
                {

                    Notification nerr = new Notification();
                    string emessage = string.Format("Cannot find statement", param.ToString(), e.Message);
                    emessage = emessage.Length > 1000 ? emessage.Substring(0, 1000) : emessage;
                    nerr.System = "SPM";
                    nerr.Message = emessage;
                    //nerr.Recipient = user;
                    nerr.Viewed = false;
                    nerr.Clicked = false;
                    nerr.DateCreated = DateTime.Now;

                    errne.Notifications.Add(nerr);
                    errne.SaveChanges();
                }

                return "FAIL";
            }

        }


        //private void UpdateCRM(Guid crmGuid, Guid crmStmtGuid, decimal? initMatch, decimal? queries)
        //{
        //    ClientCredentials clientCredentials = new ClientCredentials();
        //    clientCredentials.Windows.ClientCredential.UserName = "nav.crm";
        //    clientCredentials.Windows.ClientCredential.Password = "ultimaseries2";
        //    clientCredentials.Windows.ClientCredential.Domain = "Haystravel";
        //    string statementName = GetStatementName(crmStmtGuid);
        //    if (statementName != "FAIL")
        //    {
        //        Uri serviceUri = new Uri("http://htcrm:5555/haystravel/Xrmservices/2011/organization.svc");

        //        using (OrganizationServiceProxy service = new OrganizationServiceProxy(serviceUri, null, clientCredentials, clientCredentials))
        //        {
        //            Entity compList = service.Retrieve("caltech_tlcompletionlist", crmGuid, new Microsoft.Xrm.Sdk.Query.ColumnSet(true));

        //            Guid compListGuid = Guid.Parse(compList["caltech_tlcompletionlistid"].ToString());
        //            string compListId = compList["caltech_tlcompletionlistid"].ToString();

        //           // new EntityReference("joy_cvmlegalentity", Guid.Parse(selLegalEntity.Value));
        //            compList["caltech_statementnameid"] = new EntityReference("joy_cvmlegalentity", crmStmtGuid);
        //            compList["caltech_name"] = statementName;
        //            compList["caltech_initalmatch"] = initMatch; //From statement
        //            compList["caltech_queries"] = queries; //From match results

        //            service.Update(compList);
        //        }
        //    }
        //}

        [WebMethod]
        public void PayStatement(int param, string user)
        {
            DelegateActionPay payer = new DelegateActionPay(RunPayProc);
            payer.BeginInvoke(param, user, null, null);
        }

        private void RunPayProc(int param, string user)
        {
            try
            {
                using (OleDbConnection conn = new OleDbConnection(System.Configuration.ConfigurationManager.ConnectionStrings["cstrDW1-DWADMIN"].ConnectionString))
                {
                    conn.Open();
                    using (OleDbCommand cmd = conn.CreateCommand())
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.CommandText = "[dbo].[usp_APPS_SPM_Auto_Payment]";
                        cmd.CommandTimeout = 900;

                        cmd.Parameters.AddWithValue("@StatementID", param);

                        cmd.ExecuteNonQuery();
                    }

                    int rows = 0;

                    using (SpamEntities spam = new SpamEntities())
                    {
                        rows = spam.SPM_Statement_Lines.Where(x => x.StatementID == param && x.PaymentFlag == true).Count(); //4 should be status == paid

                        var statement = spam.SPM_Statement.Where(x => x.StatementID == param).FirstOrDefault();
                    }

                    string notiMessage = string.Format("SPAM has paid {0} rows for Statement {1}, To See the Remittance click here.", rows, param);
                    using (NotificationsEntities ne = new NotificationsEntities())
                    {
                        Notification n = new Notification();
                        Notification nr = new Notification();
                        n.System = "SPM";
                        nr.System = "SPM";
                        if (System.Environment.MachineName.ToString() == "Misssql")
                        {
                            n.Url = string.Format("http://apps/SPAM/RemittanceForm.aspx?StatementID={0}&RemitTYpe={1}", param,1);
                        }
                        else
                        {
                            n.Url = string.Format("http://DWTEST/SPAM/RemittanceForm.aspx?StatementID={0}&RemitType={1}", param,1);
                        }

                        n.Message = notiMessage;
                        n.Recipient = user;
                        n.Viewed = false;
                        n.Clicked = false;
                        n.DateCreated = DateTime.Now;

                        ne.Notifications.Add(n);
                        ne.SaveChanges();
                    }
                }
            }
            catch (Exception e)
            {
                using (NotificationsEntities errne = new NotificationsEntities())
                {
                    Notification nerr = new Notification();
                    string emessage = string.Format("Payment error: [{0}] - {1}", param.ToString(), e.Message);
                    emessage = emessage.Length > 1000 ? emessage.Substring(0, 1000) : emessage;
                    nerr.System = "SPM";
                    nerr.Message = emessage;
                    nerr.Recipient = user;
                    nerr.Viewed = false;
                    nerr.Clicked = false;
                    nerr.DateCreated = DateTime.Now;

                    errne.Notifications.Add(nerr);
                    errne.SaveChanges();
                }
            }
            
        }

        //private string ExporttoExcel(int param , int RemitType)
        //{
        //    //saving location of csv file
        //    string filepath = "M:\\8.SPAM_Output\\";

        //    string StatementID = param.ToString();
        //    string ManualPaymentID = param.ToString();
            
        //    // to build the csv file
        //    StringBuilder sb = new StringBuilder();

        
        //    if (gvwRemittance.FooterRow == null)
        //    {
        //        sb.Append("\r\n");
        //    }
        //    else
        //    {
        //        sb.Append(divAutoPayment.InnerText);
        //        sb.Append("\r\n");

        //        for (int h = 0; h < gvwRemittance.Columns.Count; h++)
        //        {
        //            sb.Append(gvwRemittance.Columns[h].HeaderText + ",");
        //        }

        //        sb.Append("\r\n");

        //        for (int r = 0; r < gvwRemittance.Rows.Count; r++)
        //        {
        //            for (int h = 0; h < gvwRemittance.Columns.Count; h++)
        //            {
        //                //to get the label value for amount due
        //                if (h == 8)
        //                {
        //                    sb.Append(((Label)gvwRemittance.Rows[r].FindControl("lblAmountDue")).Text.Replace(",", "") + ",");
        //                    continue;
        //                }
        //                sb.Append(gvwRemittance.Rows[r].Cells[h].Text.Replace(",", "").Replace("&nbsp;", "") + ",");
        //            }

        //            sb.Append("\r\n");

        //        }

        //        sb.Append("Total" + "," + "," + "," + "," + "," + "," + "," + "," + gvwRemittance.FooterRow.Cells[8].Text.Replace(",", ""));
        //    }

        //    //space between the grids
        //    sb.Append("\r\n");

        //    sb.Append("\r\n");

        //    if (gvwManualPayment.FooterRow == null)
        //    {
        //        sb.Append("\r\n");
        //    }
        //    else
        //    {
        //        sb.Append(divManualPayment.InnerText);

        //        sb.Append("\r\n");

        //        for (int h = 0; h < gvwManualPayment.Columns.Count; h++)
        //        {
        //            sb.Append(gvwManualPayment.Columns[h].HeaderText + ",");
        //        }

        //        sb.Append("\r\n");

        //        for (int r = 0; r < gvwManualPayment.Rows.Count; r++)
        //        {
        //            for (int h = 0; h < gvwManualPayment.Columns.Count; h++)
        //            {
        //                //to get the label value for amount due
        //                if (h == 8)
        //                {
        //                    sb.Append(((Label)gvwManualPayment.Rows[r].FindControl("lblAmountDue")).Text.Replace(",", "") + ",");
        //                    continue;
        //                }
        //                if (h == 8 && r == gvwManualPayment.Rows.Count)
        //                {

        //                }
        //                sb.Append(gvwManualPayment.Rows[r].Cells[h].Text.Replace(",", "").Replace("&nbsp;", "") + ",");
        //            }

        //            sb.Append("\r\n");
        //        }
        //        sb.Append("Total" + "," + "," + "," + "," + "," + "," + "," + "," + gvwManualPayment.FooterRow.Cells[8].Text.Replace(",", ""));
        //    }

        //    sb.Append("\r\n");

        //    sb.Append("\r\n");

        //    if (gvwQueires.FooterRow == null)
        //    {
        //        sb.Append("\r\n");
        //    }
        //    else
        //    {
        //        sb.Append(divQueries.InnerText);

        //        sb.Append("\r\n");

        //        for (int h = 0; h < gvwQueires.Columns.Count; h++)
        //        {
        //            sb.Append(gvwQueires.Columns[h].HeaderText + ",");
        //        }

        //        sb.Append("\r\n");

        //        for (int r = 0; r < gvwQueires.Rows.Count; r++)
        //        {
        //            for (int h = 0; h < gvwQueires.Columns.Count; h++)
        //            {
        //                //to get the label value for amount due
        //                if (h == 8)
        //                {
        //                    sb.Append(((Label)gvwQueires.Rows[r].FindControl("lblAmountDue")).Text.Replace(",", "") + ",");
        //                    continue;
        //                }

        //                sb.Append(gvwQueires.Rows[r].Cells[h].Text.Replace(",", "").Replace("&nbsp;", "") + ",");
        //            }

        //            sb.Append("\r\n");
        //        }
        //        sb.Append("Total" + "," + "," + "," + "," + "," + "," + "," + "," + gvwQueires.FooterRow.Cells[8].Text.Replace(",", ""));
        //    }

        //    //change the file name on statement or manual payment ID
        //    if (RemitType == 1)
        //    {
        //        //write the string builder to the path with the following name Remittance.csv
        //        File.WriteAllText(filepath + "RemittanceStatementID" + StatementID + ".csv", sb.ToString());
        //        return filepath + "RemittanceStatementID" + StatementID + ".csv";
        //    }
        //    else
        //    {
        //        File.WriteAllText(filepath + "RemittanceManualPaymentID" + ManualPaymentID + ".csv", sb.ToString());
        //        return filepath + "RemittanceManualPaymentID" + ManualPaymentID + ".csv";
        //    }

        //}
        [WebMethod]

        public void PayManualPayment (int param , string user)
        {
            DelegateActionPay payer = new DelegateActionPay(RunManualPayment);
            payer.BeginInvoke(param, user, null, null);
        }
        public void RunManualPayment(int param, string user)
        {
            try
            {
                using (OleDbConnection conn = new OleDbConnection(System.Configuration.ConfigurationManager.ConnectionStrings["cstrDW1-DWADMIN"].ConnectionString))
                {
                    conn.Open();
                    using (OleDbCommand cmd = conn.CreateCommand())
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.CommandText = "[dbo].[usp_APPS_SPM_Auto_Payment_Manual]";
                        cmd.CommandTimeout = 900;

                        cmd.Parameters.AddWithValue("@ManPytID_IN", param);

                        cmd.ExecuteNonQuery();
                    }
                }
                string notiMessage = string.Format("Manual Payment {0} has been processed successfully", param);
                using (NotificationsEntities ne = new NotificationsEntities())
                {
                    Notification n = new Notification();
                    n.System = "SPM";
                    if (System.Environment.MachineName.ToString() == "Misssql")
                    {
                        n.Url = string.Format("http://apps/SPAM/RemittanceForm.aspx?ManualPaymentID={0}&RemitType={1}", param,2);
                    }
                    else
                    {
                        n.Url = string.Format("http://DWTEST/SPAM/RemittanceForm.aspx?ManualPaymentID={0}&RemitType={1}", param,2);
                    }
                    n.Message = notiMessage;
                    n.Recipient = user;
                    n.Viewed = false;
                    n.Clicked = false;
                    n.DateCreated = DateTime.Now;

                    ne.Notifications.Add(n);
                    ne.SaveChanges();
                }
            }
            catch (Exception e)
            {
                using (NotificationsEntities errne = new NotificationsEntities())
                {
                    Notification nerr = new Notification();
                    string emessage = string.Format("Payment error: [{0}] - {1}", param.ToString(), e.Message);
                    emessage = emessage.Length > 1000 ? emessage.Substring(0, 1000) : emessage;
                    nerr.System = "SPM";
                    nerr.Message = emessage;
                    nerr.Recipient = user;
                    nerr.Viewed = false;
                    nerr.Clicked = false;
                    nerr.DateCreated = DateTime.Now;

                    errne.Notifications.Add(nerr);
                    errne.SaveChanges();
                }
            }
            
        }

    }
}
