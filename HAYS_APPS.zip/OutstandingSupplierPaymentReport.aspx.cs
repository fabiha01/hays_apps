﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using System.Net;

namespace Apps.SPAM
{
    public partial class OutstandingSupplierPaymentReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                OutstandingSupplierPayment("1");
            }

        }

        protected void ddlCompany_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblerror.Visible = false;

            try
            {
                OutstandingSupplierPayment(ddlCompany.SelectedValue);
            }
            catch (Exception ex)
            {
                lblerror.Text = ex.Message;
                lblerror.Visible = true;
            }
        }

        private void OutstandingSupplierPayment(string sCompany)
        {
            //IReportServerCredentials irs = new CustomReportCredentials("nav.crm", "ultimaseries2", "");

            //ReportParameter[] rptParam = new ReportParameter[1];
            //rptParam[0] = new ReportParameter();
            //rptParam[0].Name = "CompanyID";
            //rptParam[0].Values.Add(sCompany);

            //rptOutstandingSupplierReport.ProcessingMode = ProcessingMode.Remote;
            //rptOutstandingSupplierReport.ServerReport.ReportServerCredentials = irs;
            //rptOutstandingSupplierReport.ServerReport.ReportServerUrl = new Uri(Session["ReportServer"].ToString());
            //rptOutstandingSupplierReport.ServerReport.ReportPath = "/DW1 SSRS Reports/SPM_Oustanding_Supplier_Payment_Report";
            //rptOutstandingSupplierReport.ServerReport.SetParameters(rptParam);
            //rptOutstandingSupplierReport.ZoomMode = ZoomMode.PageWidth;
            //rptOutstandingSupplierReport.ServerReport.Refresh();
            //rptOutstandingSupplierReport.Visible = true;
        }

        protected void sdsOutstadingSupplierPayments_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
        {
            e.Command.CommandTimeout = 120;
        }
    }
    // report credentails 
    public class CustomReportCredentials : IReportServerCredentials
    {
        private string _UserName;
        private string _PassWord;
        private string _DomainName;

        public CustomReportCredentials(string UserName, string PassWord, string DomainName)
        {
            _UserName = UserName;
            _PassWord = PassWord;
            _DomainName = DomainName;
        }

        public System.Security.Principal.WindowsIdentity ImpersonationUser
        {
            get { return null; }
        }

        public ICredentials NetworkCredentials
        {
            get { return new NetworkCredential(_UserName, _PassWord, _DomainName); }
        }

        public bool GetFormsCredentials(out Cookie authCookie, out string user,
         out string password, out string authority)
        {
            authCookie = null;
            user = password = authority = null;
            return false;
        }
    }
}