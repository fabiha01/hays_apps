﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;

namespace Apps.SPAM
{
    public partial class RefundNotOnTheStatement : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                txtStatementID.Text = Request.QueryString["StatementID"];
                txtStatementID.Visible = false;

                lblinfoRefundsnotonstatement.Visible = false;

                if(gvwRefundsnotontheStatement.Rows.Count == 0)
                {
                    lblinfoRefundsnotonstatement.Visible = true;
                }

            }
            catch (Exception ex )
            {
                lblError.Text = ex.Message;
                lblError.Visible = true;
            }
          
        }

    }
}